/* ============================================================
   Market Radar
   Two deliberate exceptions to this site's usual zero-dependency
   rule: Leaflet.js and its Leaflet.heat plugin (via CDN, no build
   step, no npm — see market-radar.html's <head> comment). An actual
   interactive street map with real pan/zoom isn't something that
   can reasonably be hand-rolled in SVG the way this site's other
   charts are (interactive-costing-analysis.js's break-even chart is
   a handful of straight lines on a fixed grid; rendering real map
   tiles and coordinate projection from scratch is a different scale
   of problem entirely). Everything else in this file follows the
   same rules as the rest of the site: nothing persists except a
   small daily-usage counter (see MAX_ANALYSES_PER_DAY, identical
   pattern to food-worth-calculator.js), and every number that
   matters — the opportunity score, the density count, the diversity
   index — is computed with plain deterministic JS, auditable and
   never guessed by an AI. Gemini is used in exactly one place
   (requestInsight/renderInsight) and only to narrate numbers this
   file already computed, the same restrained role it plays in
   crypto-radar.js's own insight feature.

   ------------------------------------------------------------
   WHAT THIS TOOL DOES: pick a town, drop a pin on a candidate spot
   (or leave it at the town centre), pick what kind of business
   you're weighing, and see three things layered on one map:
     1. Your actual catchment area — a real walk/drive-time shape
        from OpenRouteService, not a naive circle. If OpenRouteService
        isn't configured yet, or the call fails, this falls back to
        a plain radius circle so the tool still works — just less
        precisely — rather than breaking outright.
     2. Every competitor of that category inside that catchment,
        pulled from OpenStreetMap's free Overpass API, as markers
        plus a density heatmap.
     3. An "opportunity score" — a plain, fully editable weighted
        formula (see SCORE_WEIGHTS) blending that competitor count
        against district population, household income, and category
        mix, sourced from Malaysia's own open data API (data.gov.my).

   Every stat on screen carries an Official / Estimated / Calculated
   tag (see PROVENANCE) so nothing implies more confidence than the
   source actually deserves.

   ------------------------------------------------------------
   DATA FLOW: this file never calls Overpass, OpenRouteService, or
   data.gov.my directly — everything goes through ONE Cloudflare
   Worker call (see WORKER_ENDPOINT), same pattern as every other
   proxy on this site. The Worker's job is fetching and caching raw
   data; every calculation below (the point-in-polygon catchment
   filter, the density count, the diversity index, the opportunity
   score) happens here, client-side, in the open — see
   market-radar-proxy-worker.js's own header for why the split is
   drawn exactly there.

   ------------------------------------------------------------
   KIV (planned, not built this round — see
   MARKET_RADAR_SETUP_AND_GLOSSARY.md for the fuller list):
     - AppSheet field-survey ingestion, as a fourth "Observed" layer.
     - Full MSIC-code category alignment — CATEGORY_TAGS below covers
       the ~11 categories likeliest to matter for a first F&B/retail
       business, not the full official taxonomy.
     - Momentum / trend tracking. Needs repeated snapshots taken
       weeks apart to mean anything; the momentum sub-score sits at
       a neutral 0.5 until that history exists (see
       computeOpportunityScore).
     - Wiring the rzBroadcast call below into Interactive Costing
       Analysis / Margin Analysis's own handleSyncPayload functions —
       those two files don't recognise a 'market-radar' source yet.
       That's a small, contained edit flagged in the setup doc rather
       than made here, since it touches files this session didn't own.

   ------------------------------------------------------------
   ADDED / FIXED, 2026-09-20 (package v1.4.0): the page now SHOWS where
   the competitor list came from — "OSM via Overpass (<mirror>)", or
   "OSM via Geoapify backstop" when every Overpass mirror failed — plus
   whether it was served from the 24h cache and which Worker version is
   deployed (see describePoiSource / describeWorker at the bottom of
   this file). Before this, there was no way to tell whether the Geoapify
   backstop had ever run. Also fixed: the "Nearby institutions" card said
   "None found" whenever competitor data was unavailable or came from the
   backstop — but institutions simply weren't checked in those cases, and
   "0 found" vs "not checked" must never look the same on screen (same
   principle as poisAvailable below).

   FIXED, 2026-09-16: "Drink stall / bubble tea" was invisible for
   real bubble tea shops. Root cause was in CATEGORY_TAGS below plus
   categorize() in market-radar-proxy-worker.js — see the comment on
   CATEGORY_TAGS.drinks and NAME_HINTS below for the fix. Short
   version: OSM tags a bubble tea stall as amenity=cafe (or
   amenity=fast_food) + cuisine=bubble_tea, not as its own shop type,
   so it needed a specific-tag-priority fix in the Worker, not just a
   tag added here.
   ============================================================ */

// Bumped 2026-09-20 with package v1.4.0. Check this line in the browser
// console (F12) to confirm which copy of this file the visitor is really
// running — the page can be cached separately from the Worker.
const CLIENT_VERSION = '1.4.0';
console.info('[Market Radar] script build: 2026-09-20-v6 (package v' + CLIENT_VERSION + ')');

/* ================= CONFIG =================
   Everything below is meant to be changed. See the Settings
   reference table in MARKET_RADAR_SETUP_AND_GLOSSARY.md for what
   each one does and where its starting number came from. */

// Town presets — lat/lng are approximate town centres, just a
// starting pin; click anywhere on the map to move it before
// analyzing. "district" must exactly match one of DOSM's 160 official
// district names (case doesn't matter — the Worker's ifilter= query
// is case-insensitive) — confirm any new town's spelling against
// data.gov.my/data-catalogue/population_district before adding it
// here. (An earlier version of this comment pointed at a Worker-side
// DISTRICT_ALIASES lookup table for this — that table was never
// actually built; corrected here rather than left pointing at
// something that doesn't exist.)
const TOWNS = {
  miri: { label: 'Miri', lat: 4.4148, lng: 113.9917, district: 'Miri' },
  kuching: { label: 'Kuching', lat: 1.5535, lng: 110.3593, district: 'Kuching' },
  sibu: { label: 'Sibu', lat: 2.2870, lng: 111.8305, district: 'Sibu' },
  bintulu: { label: 'Bintulu', lat: 3.1668, lng: 113.0413, district: 'Bintulu' },
};
const DEFAULT_TOWN = 'miri';

// Each category maps to one or more OpenStreetMap tag pairs. OSM
// tagging is crowd-sourced and genuinely inconsistent — a "drink
// stall" might be tagged amenity=cafe, shop=beverages, or nothing
// recognisable at all — so treat every count below as a reasonable
// signal, not a census. Add a category by adding one line; the
// dropdown, the Overpass query, and the diversity index all read
// from this same table, so nothing else needs to change.
// FEATURE, 2026-09-18: added `msic` to every category below — Malaysia's
// official 5-digit industrial classification code (MSIC 2008), used for
// SSM company registration, LHDN e-Invoicing, and DOSM's own economic
// statistics. Purely a REFERENCE annotation shown in the UI — it plays
// no part in the Overpass query or categorize() logic, which still run
// on OSM tags exactly as before. Sourced from Malaysia-specific
// documents (LHDN/hasil.gov.my's own New Business Codes MSIC2008 PDF,
// and data.gov.my's own MSIC lookup table structure), not the generic
// international ISIC codes, which occasionally diverge at this level of
// detail — cross-checked against at least two independent Malaysia-
// specific sources per code. This is also what makes the DOSM trend
// figure below possible: iowrt (Wholesale & Retail Trade Index) groups
// by 3-digit MSIC group, so `msic.code.slice(0, 3)` is the join key —
// see IOWRT_GROUPS in market-radar-proxy-worker.js. "printing" and
// "custom" have no group-level match in that index (confirmed — see
// fetchWholesaleRetailTrend's own comment), so they'll always show
// "not tracked" for that card, which is correct, not a bug.
const CATEGORY_TAGS = {
  cafe: { label: 'Cafe / kopitiam', tags: [['amenity', 'cafe']], msic: { code: '56302', name: 'Coffee shops' } },
  restaurant: { label: 'Restaurant', tags: [['amenity', 'restaurant']], msic: { code: '56101', name: 'Restaurants and restaurant cum night clubs' } },
  fastfood: { label: 'Fast food / food stall', tags: [['amenity', 'fast_food']], msic: { code: '56103', name: 'Fast-food restaurants' } },
  bakery: { label: 'Bakery / dessert', tags: [['shop', 'bakery'], ['shop', 'pastry'], ['shop', 'confectionery']], msic: { code: '47216', name: 'Retail sale of bakery products and sugar confectionery' } },
  // FIXED, 2026-09-16: added ['cuisine','bubble_tea'] — OSM's own
  // documented convention tags a bubble tea stall as amenity=cafe (or
  // amenity=fast_food) PLUS cuisine=bubble_tea; there's no dedicated
  // shop=bubble_tea tag (one was proposed and the OSM community
  // rejected it for exactly this reason — see
  // wiki.openstreetmap.org/wiki/Tag:cuisine=bubble_tea). The three
  // original tags here (shop=beverages/tea/coffee) are all real OSM
  // tags, just not the ones an actual walk-up bubble tea stall uses in
  // practice — shop=tea and shop=coffee in particular mean a retailer
  // of tea leaves or coffee beans/equipment, not a prepared-drink
  // stall. Left them in rather than removing them (harmless, and
  // occasionally still correct), but cuisine=bubble_tea is the tag
  // that actually matters. On its own this addition isn't enough —
  // market-radar-proxy-worker.js's categorize() also needed a priority
  // fix so cuisine=* tags get checked before "cafe" claims the POI
  // first; see that file's own 2026-09-16 note. NAME_HINTS below is
  // the second half of this fix, for stalls tagged amenity=cafe with
  // no cuisine sub-tag at all — common enough in practice that
  // cuisine=bubble_tea alone doesn't catch everything.
  drinks: { label: 'Drink stall / bubble tea', tags: [['cuisine', 'bubble_tea'], ['shop', 'beverages'], ['shop', 'tea'], ['shop', 'coffee']], msic: { code: '56303', name: 'Drink stalls/hawkers' } },
  minimart: { label: 'Convenience / minimart', tags: [['shop', 'convenience'], ['shop', 'supermarket']], msic: { code: '47113', name: 'Mini market' } },
  fashion: { label: 'Fashion / apparel', tags: [['shop', 'clothes'], ['shop', 'shoes']], msic: { code: '47711', name: 'Retail sale of articles of clothing, articles of fur, and clothing accessories' } },
  hardware: { label: 'Hardware', tags: [['shop', 'hardware'], ['shop', 'doityourself']], msic: { code: '47520', name: 'Retail sale of construction materials, hardware, paints, and glass' } },
  laundry: { label: 'Laundry', tags: [['shop', 'laundry']], msic: { code: '96011', name: 'Laundering and dry-cleaning of textile and fur products' } },
  salon: { label: 'Salon / barber', tags: [['shop', 'hairdresser'], ['shop', 'beauty']], msic: { code: '96020', name: 'Hairdressing and other beauty treatment' } },
  printing: { label: 'Printing / copy shop', tags: [['shop', 'copyshop'], ['shop', 'printing']], msic: { code: '82190', name: 'Photocopying, document preparation and other specialised office support activities' } },
  custom: { label: 'Custom \u2014 type your own OSM tag', tags: [], msic: null },
};

// Second half of the 2026-09-16 bubble tea fix (see CATEGORY_TAGS.drinks
// above): a real-world stall tagged plain amenity=cafe with NO
// cuisine sub-tag at all is common enough that the tag fix alone
// doesn't catch everything. A specific brand-name or generic-word
// match in the POI's own name is a strong enough signal to override
// whatever tag-based category the Worker assigned — false positives
// here are essentially impossible for a curated list like this one.
// Only "drinks" has entries for now; add another category's array
// here the same way if the same kind of mis-bucketing shows up for
// it (this is exactly the mechanism to reach for if a search ever
// "finds all F&B, then breaks down by type" runs into the same
// generic-primary-tag problem for some other category).
const NAME_HINTS = {
  drinks: [
    'bubble tea', 'boba', 'pearl milk tea',
    'chatime', 'tealive', 'gong cha', 'koi th\u00e9', 'koi the',
    'xing fu tang', 'tiger sugar', 'sharetea', 'share tea',
    'comebuy', 'come buy', 'daboba', 'the alley', 'liho', 'yifang',
    'each a cup',
  ],
};

// FEATURE, 2026-09-18: institutions that generate foot traffic without
// being a competitor to anything — the "would a food business want to
// be near this" list. Deliberately separate from CATEGORY_TAGS above:
// these are never counted as competitors, never affect the opportunity
// score, and use a plain tag match (no cuisine-tag-style priority logic
// needed — there's no ambiguity here the way "cafe vs bubble tea" had).
// Left out: large private employers/offices — OSM has no reliable tag
// for "this specific company has 200 staff", so a generic office/
// industrial-land tag would be more noise than signal. If that matters
// for a specific spot, the vacant-unit-style notepad pattern (a plain
// manual note) is the honest way to capture it, not a query this fuzzy.
const ANCHOR_TAGS = {
  school: { label: 'School', tags: [['amenity', 'school']] },
  college: { label: 'University / college', tags: [['amenity', 'university'], ['amenity', 'college']] },
  health: { label: 'Hospital / clinic', tags: [['amenity', 'hospital'], ['amenity', 'clinic']] },
  mall: { label: 'Mall / hypermarket / department store', tags: [['shop', 'mall'], ['shop', 'department_store']] },
  govt: { label: 'Government office', tags: [['office', 'government'], ['amenity', 'townhall']] },
  worship: { label: 'Place of worship', tags: [['amenity', 'place_of_worship']] },
  transport: { label: 'Bus / transport terminal', tags: [['amenity', 'bus_station'], ['aeroway', 'terminal']] },
};

// Catchment modes drive both the OpenRouteService isochrone request
// (profile + seconds) and the circle drawn instead if that call
// fails or isn't configured yet — see drawCatchment(). fallbackRadiusM
// is a rough eyeball of how far each travel mode covers in that time
// on an ordinary Malaysian town street grid, not a precise conversion,
// and radiusM sent to the Worker is 1.3x this — a deliberate
// over-fetch, since the real isochrone shape is rarely a perfect
// circle and the extra margin gets trimmed off client-side anyway
// (see pointInPolygon).
const CATCHMENT_MODES = {
  walk10: { label: '10-minute walk', profile: 'foot-walking', seconds: 600, fallbackRadiusM: 800 },
  walk15: { label: '15-minute walk', profile: 'foot-walking', seconds: 900, fallbackRadiusM: 1200 },
  drive10: { label: '10-minute drive', profile: 'driving-car', seconds: 600, fallbackRadiusM: 5000 },
  drive15: { label: '15-minute drive', profile: 'driving-car', seconds: 900, fallbackRadiusM: 8000 },
};

// Opportunity score: a plain weighted sum of five 0-1 sub-scores,
// nothing hidden or statistical about it. These five numbers are
// editable live on the page itself (#mr-weight-*) — these are only
// the starting values shown there. See computeOpportunityScore() for
// the actual formula behind each sub-score.
const SCORE_WEIGHTS_DEFAULT = { lowCompetition: 0.35, population: 0.25, income: 0.15, diversity: 0.15, momentum: 0.10, competitorStrength: 0 };

// How many competitors inside the catchment counts as "fully
// saturated" for whichever category is selected — a café-dense town
// centre and a hardware-store count don't saturate at the same
// number, so this is one visible, adjustable number rather than a
// per-category guess this file would otherwise have to invent.
const SATURATION_COUNT = 12;

// District population/income are shown as district-level context
// (that's the finest grain DOSM's open data actually publishes —
// there's no official mesh-block-level figure to fall back to), then
// scaled into a 0-1 sub-score against these two reference points.
// A district at or above these numbers maxes out that sub-score.
const POPULATION_NORMALIZER = 120000;
const INCOME_NORMALIZER = 7000; // RM/month

const MAX_ANALYSES_PER_DAY = 15; // soft cap, same reasoning as food-worth-calculator.js: protects OpenRouteService's shared 500/day free allowance and data.gov.my's 4-10 req/min limit from one browser using them all up
const USAGE_STORAGE_KEY = 'mr-usage';

// Paste your deployed Worker's URL here — see
// market-radar-proxy-worker.js's own header for deploy steps.
const WORKER_ENDPOINT = 'https://market-radar-proxy.reysourcez-ent.workers.dev/';

const PROVENANCE = {
  population: 'Official \u2014 DOSM (district-level)',
  income: 'Official \u2014 DOSM (district-level)',
  competitor: 'Estimated \u2014 OpenStreetMap',
  isochroneReal: 'Estimated \u2014 OpenRouteService travel-time shape',
  isochroneFallback: 'Estimated \u2014 radius fallback, not a real travel-time shape',
};

/* ================= SHARED UTILITIES ================= */

function escapeHTML(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
function clamp01(v) { return Math.max(0, Math.min(1, isFinite(v) ? v : 0)); }
function setStatus(text, isError) {
  const el = document.getElementById('mr-status');
  el.textContent = text;
  el.classList.toggle('is-error', !!isError);
}

/* ================= SOFT USAGE CAP (same pattern as food-worth-calculator.js) ================= */

function getUsageToday() {
  try {
    const raw = JSON.parse(localStorage.getItem(USAGE_STORAGE_KEY) || 'null');
    if (!raw || raw.day !== new Date().toDateString()) return 0;
    return raw.count;
  } catch (e) { return 0; }
}
function recordUsage() {
  try { localStorage.setItem(USAGE_STORAGE_KEY, JSON.stringify({ day: new Date().toDateString(), count: getUsageToday() + 1 })); }
  catch (e) {}
}

/* ================= WIZARD ================= */

const WIZARD_STEPS = [
  { key: 'town', question: 'Which town are you scouting?', options: Object.entries(TOWNS).map(([value, t]) => ({ value, label: t.label })) },
  { key: 'catchment', question: 'How should we measure the area around a spot?', options: Object.entries(CATCHMENT_MODES).map(([value, m]) => ({ value, label: m.label })) },
];

let wizardStepIndex = 0;
const wizardAnswers = {};

function renderWizardStep() {
  if (wizardStepIndex >= WIZARD_STEPS.length) { finishWizard(); return; }
  const step = WIZARD_STEPS[wizardStepIndex];
  const container = document.getElementById('wizard-question');
  container.innerHTML = `
    <p class="wizard-progress">Step ${wizardStepIndex + 1} of ${WIZARD_STEPS.length}</p>
    <h3>${step.question}</h3>
    <div class="wizard-options">
      ${step.options.map((o) => `<button type="button" class="wizard-option" data-value="${o.value}">${escapeHTML(o.label)}</button>`).join('')}
    </div>
  `;
  container.querySelectorAll('.wizard-option').forEach((btn) => {
    btn.addEventListener('click', () => {
      wizardAnswers[step.key] = btn.dataset.value;
      wizardStepIndex++;
      renderWizardStep();
    });
  });
  document.getElementById('wizard-back').hidden = wizardStepIndex === 0;
}
function goBack() { if (wizardStepIndex > 0) { wizardStepIndex--; renderWizardStep(); } }

function finishWizard() {
  document.getElementById('wizard').hidden = true;
  document.getElementById('mr-analysis').hidden = false;
  const town = TOWNS[wizardAnswers.town];
  document.getElementById('mr-town-label').textContent = town.label;
  document.getElementById('mr-catchment-select').value = wizardAnswers.catchment;
  initMap(town);
}
function editAnswers() {
  document.getElementById('mr-analysis').hidden = true;
  document.getElementById('wizard').hidden = false;
  wizardStepIndex = 0;
  renderWizardStep();
}

/* ================= MAP ================= */

let map, pinMarker, catchmentLayer, heatLayer;
let poiMarkers = [];
let anchorMarkers = [];

function initMap(town) {
  if (map) map.remove();
  map = L.map('mr-map').setView([town.lat, town.lng], 14);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
  }).addTo(map);
  placePin(town.lat, town.lng);
  map.on('click', (e) => placePin(e.latlng.lat, e.latlng.lng));
}

// Click anywhere on the map to move the pin there — that's the
// whole point of the tool: test one exact shoplot, not just "near
// the town centre".
function placePin(lat, lng) {
  if (pinMarker) {
    pinMarker.setLatLng([lat, lng]);
  } else {
    pinMarker = L.marker([lat, lng], { draggable: true }).addTo(map);
    pinMarker.on('dragend', () => { const p = pinMarker.getLatLng(); placePin(p.lat, p.lng); });
  }
  document.getElementById('mr-pin-coords').textContent = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
}

function clearResultLayers() {
  if (catchmentLayer) { map.removeLayer(catchmentLayer); catchmentLayer = null; }
  if (heatLayer) { map.removeLayer(heatLayer); heatLayer = null; }
  poiMarkers.forEach((m) => map.removeLayer(m));
  poiMarkers = [];
  anchorMarkers.forEach((m) => map.removeLayer(m));
  anchorMarkers = [];
}

// Draws whatever catchment shape came back — a real isochrone
// polygon from OpenRouteService, or a plain circle (matching the
// same mode's fallbackRadiusM) if that call failed or wasn't
// configured. Either branch returns the SAME shape (a Leaflet layer
// plus a containsPoint test), so nothing downstream needs to know
// which case it was — see the "isReal" flag only for the legend/
// provenance label.
function drawCatchment(isochroneGeoJSON, centerLat, centerLng, mode) {
  if (isochroneGeoJSON && isochroneGeoJSON.features && isochroneGeoJSON.features[0]) {
    catchmentLayer = L.geoJSON(isochroneGeoJSON, { style: { color: '#1F6F5C', weight: 2, fillOpacity: 0.08 } }).addTo(map);
    // GeoJSON coordinates are [lng, lat]; Leaflet and every other
    // coordinate pair in this file are [lat, lng]. Flipping this is
    // the single easiest bug to introduce when touching this
    // function — the swap below is deliberate, not a typo.
    const ring = isochroneGeoJSON.features[0].geometry.coordinates[0];
    const latLngRing = ring.map(([lng, lat]) => [lat, lng]);
    return { layer: catchmentLayer, containsPoint: (lat, lng) => pointInPolygon(lat, lng, latLngRing), areaKm2: ringAreaKm2(latLngRing, centerLat), isReal: true };
  }
  const radiusM = CATCHMENT_MODES[mode].fallbackRadiusM;
  catchmentLayer = L.circle([centerLat, centerLng], { radius: radiusM, color: '#5C6D64', weight: 2, dashArray: '5 4', fillOpacity: 0.05 }).addTo(map);
  return {
    layer: catchmentLayer,
    containsPoint: (lat, lng) => haversineMeters(centerLat, centerLng, lat, lng) <= radiusM,
    areaKm2: Math.PI * (radiusM / 1000) ** 2,
    isReal: false,
  };
}

// Standard ray-casting point-in-polygon test. Needed because Overpass
// only knows how to fetch "everything within a circle" (see the
// Worker) — the actual catchment is whatever shape OpenRouteService
// returned, so every fetched point still has to be tested against
// the real polygon, not just trusted because it came back at all.
function pointInPolygon(lat, lng, ring) {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [latI, lngI] = ring[i], [latJ, lngJ] = ring[j];
    const intersect = ((lngI > lng) !== (lngJ > lng)) && (lat < (latJ - latI) * (lng - lngI) / (lngJ - lngI) + latI);
    if (intersect) inside = !inside;
  }
  return inside;
}
function haversineMeters(lat1, lng1, lat2, lng2) {
  const R = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180, dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
// Shoelace-formula polygon area, converted from degrees to km\u00b2
// using a flat-earth approximation local to one small area \u2014
// genuinely wrong at continent scale, entirely fine for a
// 10-minute catchment inside one town.
function ringAreaKm2(ring, centerLat) {
  const kmPerDegLat = 111.32;
  const kmPerDegLng = 111.32 * Math.cos(centerLat * Math.PI / 180);
  let area = 0;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [latI, lngI] = ring[i], [latJ, lngJ] = ring[j];
    area += (lngJ * kmPerDegLng) * (latI * kmPerDegLat) - (lngI * kmPerDegLng) * (latJ * kmPerDegLat);
  }
  return Math.abs(area / 2);
}

/* ================= OPPORTUNITY SCORE (pure functions, no DOM) ================= */

// Every sub-score is clamped 0-1 so the weighted sum always lands
// 0-1 no matter how extreme the inputs get \u2014 a spot with zero
// competitors gets a full 1.0 on that one component, not an infinite
// score, the same "clamp, don't crash" instinct as everywhere else
// on this site.
function computeOpportunityScore(inputs, weights) {
  const lowCompetition = clamp01(1 - inputs.competitorCount / SATURATION_COUNT);
  const population = clamp01(inputs.districtPopulation / POPULATION_NORMALIZER);
  const income = clamp01(inputs.districtIncome / INCOME_NORMALIZER);
  const diversity = clamp01(inputs.diversityIndex);
  const momentum = 0.5; // neutral placeholder \u2014 see the KIV note at the top of this file
  const competitorStrength = computeCompetitorStrengthFactor(inputs);

  const weightSum = weights.lowCompetition + weights.population + weights.income + weights.diversity + weights.momentum + weights.competitorStrength || 1;
  const total = (weights.lowCompetition * lowCompetition + weights.population * population
    + weights.income * income + weights.diversity * diversity + weights.momentum * momentum
    + weights.competitorStrength * competitorStrength) / weightSum;
  // Dividing by weightSum means an off-target total (weights not
  // summing to exactly 1.00) still produces a sane 0-1 score instead
  // of silently over- or under-counting \u2014 the on-page warning
  // when weights don't sum to 1.00 is about transparency, not about
  // preventing a broken calculation.
  return { total: clamp01(total), parts: { lowCompetition, population, income, diversity, momentum, competitorStrength } };
}

// Per-competitor "how proven a threat is this, really" read from
// Google's rating + review count, 0 (unproven/thin) to 1 (an
// established, well-loved incumbent). Needs BOTH a strong rating AND
// a meaningful review count \u2014 a 5.0 with 2 reviews isn't a real
// signal yet; log10 keeps one enormously-reviewed chain from
// dominating the average on its own. This exact formula is a
// judgement call, not a fact \u2014 reasonable people could weight
// rating vs. volume differently; it's isolated here specifically so
// it's easy to find and change.
function competitorPoiStrength(rating, reviewCount) {
  const ratingPart = clamp01((rating || 0) / 5);
  const volumePart = clamp01(Math.log10((reviewCount || 0) + 1) / 3); // ~1,000 reviews maxes this out
  return clamp01(ratingPart * volumePart);
}

// FEATURE, 2026-09-16: the "competitor strength" signal \u2014 off
// (weight 0) by default in SCORE_WEIGHTS_DEFAULT, so this has zero
// effect on anyone who doesn't deliberately raise the weight in the
// panel below. When it IS turned on, priority order: a fresh,
// in-person "observed" read (mr-observed-busyness on the page) beats
// an aggregate Google rating, which beats the neutral 0.5 used when
// neither is available \u2014 same "unused signal changes nothing"
// pattern as the momentum placeholder above. Deliberately a
// SEPARATE weight from lowCompetition rather than folded into it:
// "3 quiet competitors" and "3 competitors with a queue out the
// door" are genuinely different situations, and collapsing them into
// one number would hide that distinction instead of surfacing it.
function computeCompetitorStrengthFactor(inputs) {
  if (inputs.observedBusyness != null) {
    // 1 (very quiet) -> 1.0 (favorable, weak competition)
    // 5 (packed)     -> 0.0 (unfavorable, strong competition)
    return clamp01(1 - (inputs.observedBusyness - 1) / 4);
  }
  const sample = inputs.competitorRatingSample || [];
  if (sample.length) {
    const avgStrength = sample.reduce((s, c) => s + competitorPoiStrength(c.rating, c.reviewCount), 0) / sample.length;
    return clamp01(1 - avgStrength);
  }
  return 0.5;
}

// Herfindahl-style concentration across every category found nearby
// (not just the one selected), inverted so 1.0 = healthily mixed and
// 0.0 = one category totally dominates the area.
function computeDiversityIndex(categoryCounts) {
  const total = Object.values(categoryCounts).reduce((s, n) => s + n, 0);
  if (total === 0) return 1;
  const hhi = Object.values(categoryCounts).reduce((s, n) => s + (n / total) ** 2, 0);
  return clamp01(1 - hhi);
}

function scoreVerdict(score) {
  if (score >= 0.75) return 'Strong opportunity';
  if (score >= 0.55) return 'Worth a closer look';
  if (score >= 0.35) return 'Competitive, proceed carefully';
  return 'Crowded \u2014 hard to stand out here';
}

/* ================= WORKER CALL ================= */

async function fetchAnalysis(payload) {
  let response;
  try {
    response = await fetch(WORKER_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
  } catch (e) {
    throw new Error('Could not reach the analysis service \u2014 check WORKER_ENDPOINT is correct and this page\u2019s URL is in the Worker\u2019s ALLOWED_ORIGINS.');
  }
  let data;
  try { data = await response.json(); }
  catch (e) { throw new Error('Got an unreadable response from the analysis service. Try again.'); }
  if (!response.ok) throw new Error(data.error || ('Analysis failed (error ' + response.status + '). Try again.'));
  return data;
}

/* ================= ANALYZE FLOW ================= */

// Runs once, right after fetchAnalysis returns, before anything else
// touches the POI list — see NAME_HINTS above. A specific keyword or
// brand-name match is treated as MORE reliable than whatever tag-based
// category the Worker assigned, so it always wins when one is found;
// a POI with no name match keeps whatever category it already had.
function applyNameHints(pois) {
  return pois.map((p) => {
    const name = (p.name || '').toLowerCase();
    for (const [key, hints] of Object.entries(NAME_HINTS)) {
      if (hints.some((h) => name.includes(h))) return { ...p, category: key };
    }
    return p;
  });
}

let lastAnalysis = null; // holds everything recomputeScore() and requestInsight() need without re-fetching

// Plain notepad, not a data source — see the structure-note next to the
// panel in market-radar.html for why no live vacancy data exists to
// fetch here. Resets on reload, same as every other input on this page.
let vacantUnits = [];

function renderVacancyList() {
  const list = document.getElementById('mr-vacancy-list');
  list.innerHTML = vacantUnits.map((v, i) =>
    `<li><span>${escapeHTML(v.floor)} \u2014 ${escapeHTML(v.detail)}</span><button type="button" data-idx="${i}" aria-label="Remove">\u2715</button></li>`
  ).join('');
  list.querySelectorAll('button[data-idx]').forEach((btn) => {
    btn.addEventListener('click', () => { vacantUnits.splice(Number(btn.dataset.idx), 1); renderVacancyList(); });
  });
}

// FIXED, 2026-09-16: with three Overpass mirrors plus a Geoapify
// fallback now each getting their own timeout (see
// EXTERNAL_CALL_TIMEOUT_MS in market-radar-proxy-worker.js), a worst-
// case analysis can genuinely take up to about 40 seconds if every
// single data source is having a bad day. Before this, the status
// line just said "Fetching\u2026" the entire time, which is exactly what
// "taking a long time and doesn't appear to complete" looks like from
// the outside \u2014 there was no way to tell a slow-but-working request
// apart from a genuinely stuck one. This cycles through a couple of
// honest, reassuring messages instead of one static line, and gets
// stopped in analyzeSpot's own finally block the moment a real
// answer (success or failure) comes back.
const PROGRESS_MESSAGES = [
  'Fetching competitors, catchment shape, and district data\u2026',
  'Still working \u2014 the first data source is slow to answer, trying another\u2026',
  'Still working \u2014 some of these are free, shared services and occasionally slow. Worst case this takes under a minute.',
];
function startProgressMessages() {
  let i = 0;
  setStatus(PROGRESS_MESSAGES[0]);
  const timer = setInterval(() => {
    i = Math.min(i + 1, PROGRESS_MESSAGES.length - 1);
    setStatus(PROGRESS_MESSAGES[i]);
  }, 7000);
  return () => clearInterval(timer);
}

function currentWeights() {
  return {
    lowCompetition: parseFloat(document.getElementById('mr-weight-lowCompetition').value) || 0,
    population: parseFloat(document.getElementById('mr-weight-population').value) || 0,
    income: parseFloat(document.getElementById('mr-weight-income').value) || 0,
    diversity: parseFloat(document.getElementById('mr-weight-diversity').value) || 0,
    momentum: parseFloat(document.getElementById('mr-weight-momentum').value) || 0,
    competitorStrength: parseFloat(document.getElementById('mr-weight-competitorStrength').value) || 0,
  };
}

function updateWeightTotalDisplay() {
  const w = currentWeights();
  const sum = w.lowCompetition + w.population + w.income + w.diversity + w.momentum + w.competitorStrength;
  const el = document.getElementById('mr-weight-total');
  el.textContent = sum.toFixed(2);
  el.classList.toggle('is-off', Math.abs(sum - 1) > 0.01);
}

// mr-observed-busyness is deliberately read fresh here rather than
// baked into lastAnalysis once at analyze-time \u2014 same reason the
// weight inputs are read fresh in currentWeights(): the person should
// be able to add or change their on-site read after the fact and see
// the score respond immediately, exactly like nudging a weight slider.
// Nothing here is saved anywhere \u2014 it resets when the tab closes,
// same as every other input on this page.
function getObservedBusyness() {
  const el = document.getElementById('mr-observed-busyness');
  const v = el ? el.value : '';
  return v ? Number(v) : null;
}

function scoreInputs() {
  return lastAnalysis ? { ...lastAnalysis, observedBusyness: getObservedBusyness() } : lastAnalysis;
}

function renderScore() {
  if (!lastAnalysis) return;
  const result = computeOpportunityScore(scoreInputs(), currentWeights());
  document.getElementById('mr-score-banner').hidden = false;
  document.getElementById('mr-score-number').textContent = Math.round(result.total * 100);
  document.getElementById('mr-score-verdict').textContent = lastAnalysis.poisAvailable
    ? scoreVerdict(result.total)
    : scoreVerdict(result.total) + ' \u2014 based on partial data, competitor count unavailable';
}

async function analyzeSpot() {
  const town = TOWNS[wizardAnswers.town];
  const catchmentModeKey = document.getElementById('mr-catchment-select').value;
  const catchmentMode = CATCHMENT_MODES[catchmentModeKey];
  const categoryKey = document.getElementById('mr-category-select').value;
  const pin = pinMarker.getLatLng();

  let categoriesForRequest = CATEGORY_TAGS;
  if (categoryKey === 'custom') {
    const key = document.getElementById('mr-custom-key').value.trim();
    const value = document.getElementById('mr-custom-value').value.trim();
    if (!key || !value) { setStatus('Type both an OSM key and value for a custom category first.', true); return; }
    categoriesForRequest = { custom: { label: `${key}=${value}`, tags: [[key, value]] } };
  }
  if (!WORKER_ENDPOINT || WORKER_ENDPOINT.indexOf('PASTE_YOUR') === 0) {
    setStatus('This tool needs its proxy URL set \u2014 see WORKER_ENDPOINT near the top of market-radar.js.', true);
    return;
  }
  if (getUsageToday() + 1 > MAX_ANALYSES_PER_DAY) {
    setStatus('This browser has hit today\u2019s analysis limit. Try again tomorrow.', true);
    return;
  }

  const btn = document.getElementById('mr-analyze-btn');
  btn.disabled = true;
  const stopProgress = startProgressMessages();
  clearResultLayers();

  try {
    const data = await fetchAnalysis({
      lat: pin.lat, lng: pin.lng,
      radiusM: Math.round(catchmentMode.fallbackRadiusM * 1.3),
      categories: categoriesForRequest,
      selectedCategory: categoryKey,
      anchors: ANCHOR_TAGS,
      isochrone: { profile: catchmentMode.profile, seconds: catchmentMode.seconds },
      district: town.district,
    });
    recordUsage();
    const sourceLabel = describePoiSource(data);

    const catchment = drawCatchment(data.isochrone, pin.lat, pin.lng, catchmentModeKey);

    const pois = applyNameHints(data.pois || []);
    const withinCatchment = pois.filter((p) => catchment.containsPoint(p.lat, p.lng));
    const competitors = withinCatchment.filter((p) => p.category === categoryKey || categoryKey === 'custom');
    const categoryCounts = {};
    withinCatchment.forEach((p) => { categoryCounts[p.category] = (categoryCounts[p.category] || 0) + 1; });
    // Only populated when GOOGLE_PLACES_API_KEY is set on the Worker
    // — see attachGooglePopularity() in market-radar-proxy-worker.js.
    // Every competitor still counts toward competitorCount above
    // whether or not it has a rating; this is a separate, optional
    // refinement, not a filter.
    const competitorRatingSample = competitors.filter((p) => p.rating != null).map((p) => ({ rating: p.rating, reviewCount: p.reviewCount || 0 }));

    poiMarkers = competitors.map((p) => L.circleMarker([p.lat, p.lng], { radius: 6, color: '#C0392B', fillColor: '#C0392B', fillOpacity: 0.7, weight: 1 }).bindTooltip(escapeHTML(p.name || 'Unnamed')).addTo(map));
    if (competitors.length > 0 && typeof L.heatLayer === 'function') {
      // CORRECTED, 2026-09-18: this always looked flat blue, and it
      // wasn't a rendering fluke — Leaflet.heat's DEFAULT max is 1.0,
      // and every point here was weighted only 0.6, so even a single,
      // fully isolated competitor could never cross about the "cyan"
      // mark on the default gradient (which only starts leaving blue
      // around 0.4 and doesn't reach red until 1.0) — let alone red.
      // With typically single-digit-to-a-few-dozen competitors per
      // search, that default is calibrated for a completely different
      // scale of data (crime incidents across a city, thousands of
      // points) than this tool ever has. Recalibrated so the scale
      // means something concrete: max=3 treats "3 competitors of the
      // SAME category overlapping in one spot" as fully saturated —
      // a meaningful, genuinely-worth-flagging micro-cluster at this
      // tool's scale, not an arbitrary number. One isolated competitor
      // now correctly shows as a clear, visible warm color rather than
      // barely-there blue; it's only actual overlapping density that
      // pushes further toward red. This also means: a spot with only
      // 1-2 well-spaced competitors SHOULD look mild, not dramatic —
      // that's the heat map correctly reporting "not much clustering
      // here", not a sign it's still broken.
      heatLayer = L.heatLayer(competitors.map((p) => [p.lat, p.lng, 1]), {
        radius: 35,
        blur: 25,
        max: 3,
        gradient: { 0.15: '#1F6F5C', 0.5: '#E8A33D', 1: '#C0392B' },
      });
      if (document.getElementById('mr-heat-toggle').checked) heatLayer.addTo(map);
    }

    // Anchors are informational only — never counted as competitors,
    // never touch the opportunity score. Distinct blue square icon
    // (via a plain divIcon, no extra image asset to load) so they're
    // visually unmistakable from the red competitor dots at a glance.
    const anchorList = data.anchors || [];
    anchorMarkers = anchorList.map((a) => L.marker([a.lat, a.lng], {
      icon: L.divIcon({ className: 'mr-anchor-icon', html: '\u25a0', iconSize: [14, 14] }),
    }).bindTooltip(escapeHTML(a.name || 'Unnamed') + ' \u2014 ' + escapeHTML((ANCHOR_TAGS[a.anchorType] || {}).label || a.anchorType)).addTo(map));

    if (catchment.layer) map.fitBounds(catchment.layer.getBounds(), { padding: [20, 20] });

    lastAnalysis = {
      competitorCount: competitors.length,
      diversityIndex: computeDiversityIndex(categoryCounts),
      districtPopulation: data.demographics ? data.demographics.population : 0,
      districtIncome: data.demographics ? data.demographics.medianIncome : 0,
      catchmentAreaKm2: catchment.areaKm2,
      catchmentIsReal: catchment.isReal,
      districtLabel: town.district,
      categoryLabel: categoryKey === 'custom' ? categoriesForRequest.custom.label : CATEGORY_TAGS[categoryKey].label,
      competitorRatingSample,
      anchorCount: anchorList.length,
      wholesaleRetailTrend: data.wholesaleRetailTrend || null,
      // False when the Worker's Overpass call failed entirely (see
      // market-radar-proxy-worker.js's poisError). "0 competitors"
      // and "we couldn't check" must never look the same on screen —
      // the first is a real, useful finding; the second is a data
      // outage that would otherwise read as a suspiciously perfect
      // opportunity score.
      poisAvailable: !data.poisError,
    };

    if (lastAnalysis.poisAvailable) {
      document.getElementById('mr-competitor-count').innerHTML = `${lastAnalysis.competitorCount}${provenanceHTML((catchment.isReal ? PROVENANCE.isochroneReal : PROVENANCE.isochroneFallback) + ' \u00b7 ' + sourceLabel)}`;
      document.getElementById('mr-diversity-value').textContent = Math.round(lastAnalysis.diversityIndex * 100) + '% mixed';
    } else {
      document.getElementById('mr-competitor-count').innerHTML = `Unavailable${provenanceHTML('Overpass error \u2014 see status message below \u00b7 ' + describeWorker(data))}`;
      document.getElementById('mr-diversity-value').innerHTML = `Unavailable${provenanceHTML('Overpass error \u2014 see status message below')}`;
    }
    document.getElementById('mr-population-value').textContent = lastAnalysis.districtPopulation ? lastAnalysis.districtPopulation.toLocaleString() : 'Not available';
    document.getElementById('mr-income-value').textContent = lastAnalysis.districtIncome ? ('RM' + Math.round(lastAnalysis.districtIncome).toLocaleString() + '/mo') : 'Not available';
    if (competitorRatingSample.length) {
      const avgRating = competitorRatingSample.reduce((s, c) => s + c.rating, 0) / competitorRatingSample.length;
      document.getElementById('mr-popularity-value').textContent = `${competitorRatingSample.length} of ${competitors.length} matched, avg ${avgRating.toFixed(1)}\u2605`;
      document.getElementById('mr-popularity-provenance').textContent = 'Estimated \u2014 Google Places';
    } else {
      document.getElementById('mr-popularity-value').textContent = 'No Google match';
      document.getElementById('mr-popularity-provenance').textContent = 'Not available \u2014 GOOGLE_PLACES_API_KEY unset, or no nearby Google listing matched';
    }

    const anchorCounts = {};
    anchorList.forEach((a) => { anchorCounts[a.anchorType] = (anchorCounts[a.anchorType] || 0) + 1; });
    const anchorSummary = Object.entries(anchorCounts).map(([k, n]) => `${n} ${(ANCHOR_TAGS[k] || {}).label || k}`).join(', ');
    if (data.poisSource === 'geoapify') {
      // The backstop only maps competitor categories, so institutions were never looked up.
      document.getElementById('mr-anchor-value').textContent = 'Not checked';
      document.getElementById('mr-anchor-provenance').textContent = 'Backstop source has no institution mapping \u2014 run again once Overpass recovers';
    } else if (data.poisError) {
      document.getElementById('mr-anchor-value').textContent = 'Not checked';
      document.getElementById('mr-anchor-provenance').textContent = 'Overpass unavailable \u2014 see status message';
    } else {
      document.getElementById('mr-anchor-value').textContent = anchorList.length ? anchorList.length : 'None found';
      document.getElementById('mr-anchor-provenance').textContent = anchorList.length ? ('Official \u2014 OSM: ' + anchorSummary) : 'Official \u2014 OSM (none of the tracked types found nearby)';
    }

    const trend = lastAnalysis.wholesaleRetailTrend;
    if (trend) {
      const sign = trend.growthYoy > 0 ? '+' : '';
      document.getElementById('mr-trend-value').textContent = `${sign}${trend.growthYoy.toFixed(1)}% YoY`;
      document.getElementById('mr-trend-provenance').textContent = `Official \u2014 DOSM, as of ${trend.asOf} \u00b7 Malaysia-wide, not ${town.label}-specific`;
    } else {
      document.getElementById('mr-trend-value').textContent = 'Not tracked';
      document.getElementById('mr-trend-provenance').textContent = `${lastAnalysis.categoryLabel} isn't part of DOSM's wholesale & retail trade index (it only covers 4 of the 11 categories here \u2014 see the tooltip)`;
    }

    document.getElementById('mr-result-cards').hidden = false;
    document.getElementById('mr-field-note-panel').hidden = false;
    document.getElementById('mr-vacancy-panel').hidden = false;
    document.getElementById('mr-weights-panel').hidden = false;
    updateWeightTotalDisplay();
    renderScore();

    document.getElementById('mr-ai-insight').textContent = 'Click "Get a plain-English read" below for a summary of what these numbers suggest.';
    document.getElementById('mr-ai-insight').classList.add('is-empty');

    if (data.poisError) {
      // The Worker version is appended so "is the old Worker still live?" is answerable from the screen.
      setStatus(data.poisError + ' [' + describeWorker(data) + ']', true);
    } else if (data.poisSource === 'geoapify') {
      setStatus(`Found ${lastAnalysis.competitorCount} matching ${lastAnalysis.categoryLabel} competitor${lastAnalysis.competitorCount === 1 ? '' : 's'} in this catchment. Overpass was unavailable, so this came from the Geoapify backstop instead \u2014 nearby institutions weren't checked in this mode.` + (data.poisTruncated ? ' The backstop hit its 500-place cap (nearest places are kept first), so this count may be an undercount \u2014 try a shorter catchment.' : ''));
    } else {
      setStatus(`Found ${lastAnalysis.competitorCount} matching ${lastAnalysis.categoryLabel} competitor${lastAnalysis.competitorCount === 1 ? '' : 's'} in this catchment.`);
    }

    // Broadcasts if costing-sync.js is loaded and a listener exists —
    // see this file's own KIV note: Interactive Costing Analysis and
    // Margin Analysis don't read a 'market-radar' source yet, so this
    // currently reaches no one, but the shape is ready the moment
    // that small receiving-side edit is made.
    if (typeof rzBroadcast === 'function') {
      rzBroadcast({ source: 'market-radar', category: lastAnalysis.categoryLabel, district: lastAnalysis.districtLabel, competitorCount: lastAnalysis.competitorCount, opportunityScore: computeOpportunityScore(scoreInputs(), currentWeights()).total });
    }
  } catch (err) {
    setStatus(err.message || 'Something went wrong. Try again.', true);
  } finally {
    stopProgress();
    btn.disabled = false;
  }
}
function provenanceHTML(text) { return `<span class="mr-provenance">${escapeHTML(text)}</span>`; }

// Which Worker answered, e.g. "Worker v1.4.0". A Worker older than v1.4.0
// sends no version at all — say so plainly, because "the old file is
// still deployed" is the most common reason a fix appears not to work.
function describeWorker(data) {
  return data && data.workerVersion ? ('Worker v' + data.workerVersion) : 'Worker version unknown \u2014 older than v1.4.0, redeploy it';
}

// Where the competitor list actually came from, in plain words. Pure
// function on purpose: no DOM, easy to check on its own.
function describePoiSource(data) {
  const src = (data && data.poisSource) || '';
  let label;
  if (src === 'geoapify') label = 'OSM via Geoapify backstop (Overpass was unavailable)';
  else if (src.indexOf('overpass:') === 0) label = 'OSM via Overpass (' + src.slice('overpass:'.length) + ')';
  else if (src === 'overpass') label = 'OSM via Overpass';
  else label = 'OpenStreetMap';
  if (data && data.poisCached) label += ', cached up to 24h';
  return label + ' \u00b7 ' + describeWorker(data);
}

/* ================= GEMINI INSIGHT (narration only \u2014 see this file's own header) ================= */

async function getInsight() {
  if (!lastAnalysis) return;
  const box = document.getElementById('mr-ai-insight');
  box.textContent = 'Asking Gemini for a plain-English read\u2026';
  box.classList.remove('is-empty');
  try {
    const score = computeOpportunityScore(scoreInputs(), currentWeights());
    const data = await fetchAnalysis({
      mode: 'insight',
      snapshot: {
        town: TOWNS[wizardAnswers.town].label,
        category: lastAnalysis.categoryLabel,
        competitorCount: lastAnalysis.competitorCount,
        diversityIndex: lastAnalysis.diversityIndex,
        districtPopulation: lastAnalysis.districtPopulation,
        districtIncome: lastAnalysis.districtIncome,
        opportunityScore: Math.round(score.total * 100),
        catchmentIsReal: lastAnalysis.catchmentIsReal,
      },
    });
    box.textContent = data.text || 'Gemini didn\u2019t return anything usable that time \u2014 the numbers above are unaffected.';
    box.classList.remove('is-empty');
  } catch (err) {
    box.textContent = 'Couldn\u2019t reach Gemini right now (' + (err.message || 'unknown error') + '). The numbers above are unaffected.';
    box.classList.add('is-empty');
  }
}

/* ================= INIT ================= */

let rzInitialized = false;

function init() {
  if (rzInitialized) return;
  rzInitialized = true;

  const categorySelect = document.getElementById('mr-category-select');
  categorySelect.innerHTML = Object.entries(CATEGORY_TAGS).map(([value, c]) => `<option value="${value}">${escapeHTML(c.label)}</option>`).join('');
  categorySelect.addEventListener('change', () => {
    document.getElementById('mr-custom-tag-row').classList.toggle('is-visible', categorySelect.value === 'custom');
  });

  const catchmentSelect = document.getElementById('mr-catchment-select');
  catchmentSelect.innerHTML = Object.entries(CATCHMENT_MODES).map(([value, m]) => `<option value="${value}">${escapeHTML(m.label)}</option>`).join('');

  renderWizardStep();
  document.getElementById('wizard-back').addEventListener('click', goBack);
  document.getElementById('mr-edit-answers').addEventListener('click', editAnswers);
  document.getElementById('mr-save-pdf').addEventListener('click', () => window.print());
  document.getElementById('mr-analyze-btn').addEventListener('click', analyzeSpot);
  document.getElementById('mr-get-insight').addEventListener('click', getInsight);

  ['lowCompetition', 'population', 'income', 'diversity', 'momentum', 'competitorStrength'].forEach((key) => {
    document.getElementById('mr-weight-' + key).addEventListener('input', () => { updateWeightTotalDisplay(); renderScore(); });
  });

  const observedEl = document.getElementById('mr-observed-busyness');
  if (observedEl) observedEl.addEventListener('change', renderScore);

  document.getElementById('mr-vacancy-add').addEventListener('click', () => {
    const detailEl = document.getElementById('mr-vacancy-detail');
    const detail = detailEl.value.trim();
    if (!detail) { detailEl.focus(); return; }
    vacantUnits.push({ floor: document.getElementById('mr-vacancy-floor').value, detail });
    detailEl.value = '';
    renderVacancyList();
  });

  document.getElementById('mr-heat-toggle').addEventListener('change', (e) => {
    if (!heatLayer) return;
    if (e.target.checked) { heatLayer.addTo(map); } else { map.removeLayer(heatLayer); }
  });
}

document.addEventListener('DOMContentLoaded', init);
