/* ============================================================
   Market Radar — proxy + cache (Cloudflare Worker)
   ------------------------------------------------------------
   This file does NOT go in the reysourcez GitHub Pages repo's
   deployed site — it deploys separately, to Cloudflare Workers,
   the same way every other *-proxy-worker.js on this site does.
   Its jobs, all in one place so the browser only ever makes ONE
   call per analysis:

     1. Query OpenStreetMap's free Overpass API for every business
        matching whichever categories the browser asked about,
        within a generous radius of one point. Tries a short list of
        public mirrors in order (see OVERPASS_MIRRORS) rather than
        trusting one — the original single-endpoint version of this
        file hit a real, widely-reported reliability problem with
        overpass-api.de specifically (intermittent 406s affecting
        unrelated users too, not a bug in this Worker — see
        github.com/drolbr/Overpass-API/issues/791 and the OSM
        community forum thread on the same error) within days of
        this tool going live for real testing. If every mirror fails
        (a real, separate problem — see the 2026-09-16 note below),
        falls back to Geoapify's Places API, a key-authenticated
        (not IP-rate-limited) commercial POI source.
     2. Ask OpenRouteService (now under the HeiGIT domain, see
        ORS_ISOCHRONE_ENDPOINT) for a real walk/drive-time isochrone
        shape around that same point — or return null if that
        fails or ORS_API_KEY isn't set yet, so the browser can fall
        back to drawing a plain circle instead of breaking.
     3. Look up population and household income for one district
        from data.gov.my's open API.
     4. On a separate { mode: 'insight' } request, ask Gemini to
        narrate a snapshot the browser already computed — Gemini
        never sees raw Overpass/ORS/DOSM data directly and never
        invents a number; it only describes what's already there,
        the same restrained role it plays in crypto-radar-worker.js.

   Every external call above is cached with the Cloudflare Cache API
   (see CACHE NOTES below) — this matters more here than on this
   site's other proxies, because these sources have real shared
   limits: OpenRouteService's free tier is 500 isochrones a day
   across however many people use this key, data.gov.my allows only
   4–10 requests a MINUTE without/with an API key, and Geoapify's
   free tier is 3,000 credits/day. Caching isn't an optimization
   here, it's what keeps the tool working at all once more than a
   couple of people use it the same day.

   Contract with the browser (market-radar.js):
     Request  -> { lat, lng, radiusM, categories: { key: { label, tags: [[k,v],...] } },
                   selectedCategory, isochrone: { profile, seconds }, district }
                 or { mode: 'insight', snapshot: {...} }
     Response -> { pois: [{ name, lat, lng, category }], anchors: [...],
                   isochrone: GeoJSON|null,
                   demographics: { population, medianIncome },
                   poisError: string|null,   // set when NO competitor source answered
                   poisSource: 'overpass:<mirror host>' | 'geoapify' | null,
                   poisCached: boolean,      // true = served from the 24h cache
                   poisTruncated: boolean,   // true = the Geoapify backstop hit its place cap (possible undercount)
                   workerVersion: 'x.y.z' }  // which copy of this file is deployed
                 or { text: "..." } / { error: "..." }

   DEPLOY STEPS (Cloudflare dashboard, no local tooling needed):
     1. dash.cloudflare.com -> Workers & Pages -> Create -> Create Worker.
     2. Name it (e.g. market-radar-proxy) -> Deploy the default
        template first, then Edit code and replace everything with
        this file's contents.
     3. Update ALLOWED_ORIGINS below to your real domain(s).
     4. Settings -> Variables and Secrets -> Add, as Secret (not
        plain text):
          GEMINI_API_KEY    — same key your other Workers use
          ORS_API_KEY       — free at account.heigit.org (openrouteservice
                              moved its whole account system there;
                              the key shown as "Basic Key" on that
                              dashboard is what goes here) — 500
                              isochrones total, 20/minute, no card
                              required. openrouteservice.org's OLD
                              signup path still exists but funnels
                              through the same account.heigit.org
                              system now, so either route ends up
                              the same place.
          GEOAPIFY_API_KEY  — free at myprojects.geoapify.com, no
                              card, 3,000 credits/day. Only ever
                              called when every OVERPASS_MIRRORS
                              entry has already failed — see the
                              2026-09-16 note below for why this
                              turned out to matter in practice, not
                              just in theory. THE SECRET'S NAME MUST
                              BE EXACTLY GEOAPIFY_API_KEY — saved under
                              any other name (or under another
                              service's name) this Worker never sees
                              it and the backstop stays off. Credits:
                              roughly 1 per 20 places returned, see
                              GEOAPIFY_RESULT_LIMIT below.
          GOOGLE_PLACES_API_KEY — optional, and genuinely different
                              from the three above: this ISN'T free.
                              Needs a Google Cloud project with
                              billing enabled and a key restricted to
                              "Places API (New)". Confirmed against
                              Google's own current pricing
                              (2026-09-16): 1,000 Nearby Search
                              "Enterprise"-tier calls/month free (the
                              tier that includes rating +
                              userRatingCount — Google's old $200/mo
                              platform-wide credit ended 28 Feb 2025
                              and was never replaced), then $35 per
                              1,000 calls. One call covers a whole
                              analysis (see fetchGooglePopularity
                              below), so that's 1,000 free ANALYSES a
                              month, not 1,000 lookups. Leave unset
                              and every feature on this page keeps
                              working exactly as before — this only
                              adds an optional "how strong are these
                              competitors, really" signal on top.
        The first three are optional in the sense that the Worker
        won't crash without them — no ORS key just means every
        catchment falls back to a plain circle; no Gemini key just
        means the "Get a plain-English read" button returns an error
        while every number on the page keeps working fine; no
        Geoapify key just means a total Overpass outage shows as an
        honest "competitor data unavailable" instead of quietly
        recovering. GOOGLE_PLACES_API_KEY is optional in a stronger
        sense: it's the one integration on this page that costs real
        money past a real limit, so it's designed to be something you
        deliberately turn on, not something you'd add "just in case."
     5. Deploy. Copy the *.workers.dev URL Cloudflare gives you.
     6. Paste that URL into WORKER_ENDPOINT in market-radar.js.

   FIXED / ADDED, 2026-09-20 (v1.4.0) — writeup in
   MARKET_RADAR_SETUP_AND_GLOSSARY.md and MARKET_RADAR_VERSION_HISTORY.md.
   Prompted by "still no Geoapify backstop?". Checked against this
   file's ACTUAL code and a mocked-network test run, not the docs: the
   backstop WAS present and works when every mirror fails hard (HTTP
   429 etc.), but it could be bypassed, and nothing showed whether it
   had run. Changes:
   (a) SOFT FAILURES no longer bypass the backstop. Overpass reports a
       timeout / out-of-memory as HTTP 200 + a "remark" field. That
       used to look like a good, empty answer: every remaining mirror
       AND Geoapify were skipped, and "0 competitors" was cached for
       24h. Now treated as a failed mirror (see the SOFT-FAILURE CHECK
       in fetchOverpassPOIs).
   (b) Geoapify features that can't be placed on the map (no usable
       lat/lon) are dropped instead of being emitted with garbage
       coordinates that would throw inside Leaflet.
   (c) The response now says which source answered (poisSource), whether
       it came from cache (poisCached) and which Worker version is live
       (workerVersion), so the page can show it.
   (d) FORCE_OVERPASS_FAIL — an optional plain-text Variable. Set it to
       1 to fire-drill the backstop end-to-end without waiting for
       Overpass to really break. Off unless exactly "1".
   (e) The error message now lists what EVERY mirror returned (it used
       to keep only the last one, contrary to what the docs said), names
       the exact secret to create when the key is missing, and gives a
       plain-English hint for Geoapify 401 / 429 / 400.
   (f) GEOAPIFY_CATEGORY_MAP re-verified against Geoapify's own
       published OpenAPI spec and docs page — all 17 strings exist.
   (g) The Geoapify key is scrubbed from any error message before it
       can reach the (public) page — a test showed it could leak when a
       network error echoed the request URL.
   (h) Geoapify's place cap applies to ALL categories combined, so a big
       drive catchment can exceed it. Results are now requested
       nearest-first (bias=proximity) and the response carries
       poisTruncated so the page can warn of a possible undercount.
   (i) FORCE_OVERPASS_FAIL also works when the dashboard variable was
       saved as JSON (a number) rather than Text.
   NOT verifiable from the test environment (no network, no real
   keys): a live call to Geoapify. Run the fire drill once after
   deploying — that is the real end-to-end proof.

   FIXED, 2026-09-16 (this round — see MARKET_RADAR_SETUP_AND_GLOSSARY.md
   for the fuller writeup):
   Re-reading this exact file turned up that three fixes described
   elsewhere as already shipped had NOT actually made it into this
   file's own code — flagging that plainly here so a future session
   trusts what this file actually does over what any doc claims it
   does. All three are genuinely implemented as of this version:

   (a) Bubble tea / "drinks" category was invisible. Root cause: OSM's
       own documented convention tags a bubble tea stall as
       amenity=cafe (or amenity=fast_food) PLUS cuisine=bubble_tea —
       there's no dedicated shop=bubble_tea tag; one was proposed and
       the OSM community rejected it for exactly this reason (see
       wiki.openstreetmap.org/wiki/Tag:cuisine=bubble_tea). categorize()
       below only ever checked primary amenity / shop tags, and
       checked categories in the order CATEGORY_TAGS lists them —
       "cafe" comes before "drinks", so any bubble tea stall tagged
       amenity=cafe (the common case) matched "cafe" first and never
       got a chance to be recognised as "drinks" at all. Fixed by
       giving cuisine=* tag pairs priority over every other tag,
       regardless of category order — see categorize() below. The
       matching fix on the tag-definition side (adding
       ['cuisine','bubble_tea'] to "drinks") lives in market-radar.js's
       CATEGORY_TAGS, plus a name-based fallback (NAME_HINTS) there
       too, for the real-world cases where a stall is tagged
       amenity=cafe with no cuisine sub-tag at all.
   (b) Geoapify backstop — MARKET_RADAR_SETUP_AND_GLOSSARY.md described
       this as built; it wasn't in this file. Implemented for real
       below (GEOAPIFY_CATEGORY_MAP, fetchGeoapifyPOIs,
       categorizeGeoapify), only ever called after every
       OVERPASS_MIRRORS entry has failed.
   (c) EXTERNAL_CALL_TIMEOUT_MS / a timeout wrapper — same situation,
       described as built, wasn't. Every external fetch in this file
       (Overpass, Geoapify, ORS, data.gov.my, Gemini) now goes through
       fetchWithTimeout() below instead of a bare, unbounded fetch().
   (d) DOSM population was still wrong after an earlier round believed
       it had fixed this. Confirmed the actual cause and the actual
       fix against data.gov.my's OWN published API docs
       (developer.data.gov.my/request-query) and the population_district
       dataset's own metadata page (data.gov.my/data-catalogue/population_district)
       on 2026-09-16, rather than guessing again: that dataset publishes
       one row per (district × sex × age band × ethnicity) combination,
       not one row per district, and the population figure itself is
       published in THOUSANDS. See fetchPopulation() below for the
       fix — confirmed working query shape, confirmed field names,
       confirmed unit.

   FEATURE, 2026-09-16 (not a fix — new): competitor strength via
   Google Places. Answers the "does a quiet cafe and a packed,
   beloved cafe really deserve the same competitor count" question —
   see computeCompetitorStrengthFactor() in market-radar.js for the
   scoring side. This file's half: fetchGooglePopularity() makes ONE
   Nearby Search (New) call per analysis (only when
   GOOGLE_PLACES_API_KEY is set), and attachGooglePopularity() matches
   each result to an already-found, already-classified Overpass/
   Geoapify competitor by proximity (within 75m) so the rating/review
   count rides along on the SAME pois array this file already
   returned — no new field in the response contract, no change for
   anyone who doesn't set the key. Ratings are never used to decide
   WHAT a place is, only how strong a competitor it is once Overpass/
   Geoapify + this file's own categorize() has already decided that.

   CORRECTED, 2026-09-17: two small but real fixes, one of them
   prompted by comparing this file against an older draft that turned
   out to be broken (worth recording exactly what was wrong with it,
   since that draft otherwise looks plausible on a skim):
   (a) Overpass calls had NO User-Agent header at all — added
       APP_USER_AGENT below. A missing/generic User-Agent is exactly
       what abuse detection on a shared free resource is suspicious
       of, so this is a plausible contributor to Overpass failing more
       than it should, on top of the shared-IP problem Geoapify below
       exists for.
   (b) fetchPopulation()/fetchIncome() now use sort=-date&limit=1
       instead of limit=5 + client-side sort — confirmed
       sort=<column>/-<column> is a real, documented parameter at
       developer.data.gov.my/request-query (missed on the first pass
       through those docs). One fewer thing downloaded, same result.
   Neither of these is what was actually broken in the older draft,
   for the record: that draft's fetchGeoapifyPOIs() pointed
   GEOAPIFY_ENDPOINT at Geoapify's GEOCODING endpoint
   (/v1/geocode/search) with a hardcoded London address and a
   demo/placeholder API key copy-pasted straight from Geoapify's own
   docs example, THEN appended a SECOND "?" onto that already-complete
   URL to add categories/filter/limit/the real key — a URL can only
   have one "?"; everything after the first is query-string content,
   so that second "?" and everything after it, including the real
   apiKey value, just became part of the (already wrong) demo key's
   literal value. That request could only ever fail. The version in
   this file has always used the correct endpoint
   (api.geoapify.com/v2/places) with the actual lat/lng/radius
   interpolated in — confirmed against
   apidocs.geoapify.com/docs/places on 2026-09-16 — so it isn't
   affected by that specific bug. If Geoapify still doesn't seem to be
   catching Overpass failures after deploying THIS file, the fastest
   way to find out why is the poisError message market-radar.js
   already surfaces on-page after a failed analysis — it names the
   exact HTTP status or error each mirror returned, and says plainly
   whether GEOAPIFY_API_KEY is even configured.

   FIXED, 2026-09-13 (day-one live testing turned this up immediately):
   Overpass calls were failing with a 406 on the very first real
   "Analyze" click. Traced to overpass-api.de itself, not this file —
   see the note in item 1 above. Two changes: (a) fetchOverpassPOIs
   now tries OVERPASS_MIRRORS in order instead of one hardcoded
   endpoint, and sends an explicit Accept: application/json header,
   which several of the same public bug reports suggested helps; (b)
   Overpass failing now returns an honest { pois: [], error: "..." }
   instead of throwing — previously, if Overpass alone failed, the
   whole Promise.all rejected and isochrone + demographics results
   were thrown away too, even on requests where THEY had already
   succeeded. Also moved ORS_ISOCHRONE_ENDPOINT to the api.heigit.org
   domain per openrouteservice's own migration notice (api.openrouteservice.org
   still works today but has had its quota deliberately reduced since
   28 April 2026 to push this migration, and will presumably be
   switched off eventually) — the request/response shape and
   Authorization header are unchanged per that same notice, only the
   domain moved.
   ============================================================ */

const ALLOWED_ORIGINS = ['https://reysourcez.com', 'https://www.reysourcez.com'];

// Tried in order; first one that answers wins. All three run the
// identical Overpass QL language, so nothing about how the query is
// BUILT changes based on which one responds — see the 2026-09-13
// fix note above for why this is a list now instead of one endpoint.
const OVERPASS_MIRRORS = [
  'https://overpass-api.de/api/interpreter',
  'https://overpass.kumi.systems/api/interpreter',
  'https://overpass.private.coffee/api/interpreter',
];
// CORRECTED, 2026-09-17: this file was sending Overpass requests with
// no identifying User-Agent at all — a real omission, not a style
// choice. A generic/missing User-Agent is exactly what abuse
// detection on a shared free resource is designed to be suspicious
// of, and is a plausible SEPARATE contributor to Overpass failing
// more often than it should from this Worker specifically, on top of
// the shared-IP rate-limiting problem the Geoapify backstop below
// exists for. Update the URL in this string if this page ever moves.
const APP_USER_AGENT = 'ReysourcezMarketRadar/1.0 (+https://reysourcez.com/market-radar.html)';
// Moved from api.openrouteservice.org per openrouteservice's own
// migration notice — same request shape, same Authorization header,
// just a different domain. If isochrones ever start failing again
// after this, check ask.openrouteservice.org's Announcements category
// first; this is clearly still a service in the middle of a move.
const ORS_ISOCHRONE_ENDPOINT = 'https://api.heigit.org/openrouteservice/v2/isochrones/';
const DATA_GOV_MY_ENDPOINT = 'https://api.data.gov.my/data-catalogue';
const GEMINI_MODEL = 'gemini-flash-lite-latest';
const GEMINI_ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/models/';

// How long any single external call (one Overpass mirror, Geoapify,
// ORS, data.gov.my, Gemini) is allowed to hang before this Worker
// gives up on it and moves on — see market-radar.js's own
// 2026-09-16 comment in analyzeSpot for the user-facing side of
// this. Without this, one slow/hung free-tier service could make
// "Analyze" spin forever with no way to tell a slow success apart
// from a stuck request.
const EXTERNAL_CALL_TIMEOUT_MS = 10000;

// Version of THIS file. Echoed back in every analysis response
// (workerVersion) so the page can show which Worker is actually
// deployed — the fastest way to tell "my fix didn't work" apart from
// "the old file is still live". Keep in step with
// MARKET_RADAR_VERSION_HISTORY.md.
const WORKER_VERSION = '1.4.0';

// Most places Geoapify may return per backstop call (Geoapify's own
// documented maximum is 500). COST NOTE, 2026-09-20: Geoapify appears
// to bill its Places API at roughly 1 credit per 20 places RETURNED —
// inferred from Geoapify's own sample repo, which says 60,000 places/day
// are free on the 3,000-credit budget (the Places pricing section
// itself could not be read when this was checked). So a full 500-place
// answer could cost ~25 credits, and the earlier "~1-2 credits per
// search" note was too optimistic for a busy catchment. A small-town
// catchment normally returns far fewer than 500, so this only bites at
// scale; lower it to cap worst-case spend per backstop call.
const GEOAPIFY_RESULT_LIMIT = 500;

// Maps this tool's own category keys (CATEGORY_TAGS in market-radar.js)
// to Geoapify's own category taxonomy (apidocs.geoapify.com/docs/places,
// confirmed 2026-09-16; all 17 distinct strings below re-confirmed
// 2026-09-20 against Geoapify's published OpenAPI spec, whose category
// enum is the authority — one unknown category makes Geoapify reject the
// WHOLE request with a 400, so re-check this list if it is ever edited)
// — only consulted when every Overpass mirror
// has failed. Geoapify's data is itself OSM-sourced, so this is a
// second attempt at the same underlying data through a different,
// key-authenticated door, not a genuinely independent source.
// Deliberately has its OWN dedicated bubble-tea category
// (catering.cafe.bubble_tea) — unlike raw OSM/Overpass, Geoapify
// doesn't need the cuisine-tag workaround this file uses elsewhere.
// "printing" has no real Geoapify equivalent as of this writing, so
// that one category simply gets no backstop coverage — flagged
// rather than forcing a bad fit.
const GEOAPIFY_CATEGORY_MAP = {
  cafe: ['catering.cafe'],
  restaurant: ['catering.restaurant'],
  fastfood: ['catering.fast_food'],
  bakery: ['commercial.food_and_drink.bakery', 'commercial.food_and_drink.confectionery'],
  drinks: ['catering.cafe.bubble_tea', 'catering.cafe.tea', 'commercial.food_and_drink.coffee_and_tea', 'commercial.food_and_drink.drinks'],
  minimart: ['commercial.convenience', 'commercial.supermarket'],
  fashion: ['commercial.clothing'],
  hardware: ['commercial.houseware_and_hardware.hardware_and_tools', 'commercial.houseware_and_hardware.doityourself'],
  laundry: ['service.cleaning.laundry'],
  salon: ['service.beauty.hairdresser', 'service.beauty'],
  printing: [],
};

// Maps the same category keys to Google's Table A place types
// (developers.google.com/maps/documentation/places/web-service/place-types,
// confirmed current 2026-09-16) — used only by the optional
// fetchGooglePopularity() below. Google's own taxonomy has NO
// dedicated bubble-tea type (confirmed against the current full
// Table A list) — that's fine here, since this map is only ever used
// to fetch a RATING for a place already found and already correctly
// classified elsewhere in this file; it never decides what a place
// is. "printing" has no Google equivalent either, same gap as
// GEOAPIFY_CATEGORY_MAP above.
const GOOGLE_PLACE_TYPES = {
  cafe: ['cafe'],
  restaurant: ['restaurant'],
  fastfood: ['fast_food_restaurant'],
  bakery: ['bakery', 'pastry_shop', 'dessert_shop', 'confectionery'],
  drinks: ['cafe', 'tea_house', 'juice_shop'],
  minimart: ['convenience_store'],
  fashion: ['clothing_store', 'shoe_store'],
  hardware: ['hardware_store', 'home_improvement_store'],
  laundry: ['laundry'],
  salon: ['hair_salon', 'beauty_salon', 'barber_shop'],
  printing: [],
};

/* ================= CORS / RESPONSE HELPERS ================= */

function corsHeaders(origin) {
  const allow = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return { 'Access-Control-Allow-Origin': allow, 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };
}
function json(body, status, origin) {
  return new Response(JSON.stringify(body), { status: status || 200, headers: { ...corsHeaders(origin), 'Content-Type': 'application/json' } });
}
// Small, fast, non-cryptographic hash — only used to turn a long
// Overpass query string (or Geoapify category list) into a short,
// cache-key-safe string. Doesn't need to be collision-proof, just
// good enough that two DIFFERENT queries essentially never land on
// the same cache entry.
function hashString(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) hash = ((hash << 5) - hash + str.charCodeAt(i)) | 0;
  return Math.abs(hash).toString(36);
}
// Short, log-friendly host name for the poisSource label — e.g.
// 'https://overpass.kumi.systems/api/interpreter' -> 'overpass.kumi.systems'.
function hostOf(url) {
  try { return new URL(url).hostname; } catch (e) { return String(url); }
}
// FIXED, 2026-09-16: every external fetch() in this file now goes
// through this wrapper instead of being called bare — see
// EXTERNAL_CALL_TIMEOUT_MS above for why.
async function fetchWithTimeout(url, options, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs || EXTERNAL_CALL_TIMEOUT_MS);
  try {
    return await fetch(url, { ...(options || {}), signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

/* ================= 1. OVERPASS (business POIs), Geoapify backstop ================= */

// FEATURE, 2026-09-18: anchors is optional and additive — its tags get
// folded into the SAME combined query as categories (one Overpass call
// still covers everything, same batching principle as before), but
// anchors are never business categories and never touch categorize()
// below; see categorizeAnchor() further down for how they're told apart
// on the way back out.
function buildOverpassQuery(lat, lng, radiusM, categories, anchors) {
  const clauses = [];
  const tagSets = anchors ? [categories, anchors] : [categories];
  tagSets.forEach((tagSet) => {
    Object.values(tagSet).forEach((cat) => {
      (cat.tags || []).forEach(([k, v]) => {
        clauses.push(`node["${k}"="${v}"](around:${radiusM},${lat},${lng});way["${k}"="${v}"](around:${radiusM},${lat},${lng});`);
      });
    });
  });
  if (!clauses.length) return null; // e.g. an empty custom-category request
  return `[out:json][timeout:25];(${clauses.join('')});out center tags;`;
}

// FIXED, 2026-09-16: cuisine=* tag pairs are now checked FIRST, across
// every requested category, before any amenity=*/shop=* tag pair —
// regardless of which category happens to be listed first in
// CATEGORY_TAGS. Reason: a bubble tea stall is tagged amenity=cafe +
// cuisine=bubble_tea (OSM's own documented convention — see the
// 2026-09-16 header note above). Checking amenity first meant "cafe"
// (listed before "drinks" in CATEGORY_TAGS) always won before "drinks"
// ever got a chance to look at the cuisine tag, so a bubble tea shop
// searched for under "Drink stall / bubble tea" silently vanished into
// "Cafe / kopitiam" instead. This generalises: any FUTURE category
// that disambiguates itself with a cuisine=* tag (e.g. a hypothetical
// "Ice cream" category using cuisine=ice_cream) gets the same
// specific-beats-generic priority automatically, with no need to
// reorder CATEGORY_TAGS to make it work.
//
// Within each pass, first tag pair that matches still wins — a POI
// carrying tags from two of the requested categories (rare, but OSM
// tagging overlaps sometimes) gets bucketed into whichever category
// was defined first. Good enough for a density/diversity signal; not
// trying to be a perfect one-POI-one-truth classifier.
function categorize(tags, categories) {
  for (const [key, cat] of Object.entries(categories)) {
    for (const [k, v] of cat.tags || []) {
      if (k === 'cuisine' && tags[k] === v) return key;
    }
  }
  for (const [key, cat] of Object.entries(categories)) {
    for (const [k, v] of cat.tags || []) {
      if (k !== 'cuisine' && tags[k] === v) return key;
    }
  }
  return null;
}

// Plain first-match, no cuisine-priority pass needed — schools,
// hospitals, malls etc. don't share a primary tag the way "cafe" and
// "bubble tea" do, so there's no analogous ambiguity to resolve here.
function categorizeAnchor(tags, anchors) {
  for (const [key, a] of Object.entries(anchors || {})) {
    for (const [k, v] of a.tags || []) {
      if (tags[k] === v) return key;
    }
  }
  return null;
}

// Cached for 24 hours per (query text) — business listings don't
// meaningfully change hour to hour, and this respects Overpass's own
// shared fair-use policy across everyone using this Worker, not just
// whoever's visiting right now.
//
// Returns { pois, error } rather than a bare array, and NEVER throws
// on a data-source failure — every mirror AND Geoapify failing is a
// real, honest possibility, and the router below still has an
// isochrone and demographics result worth returning even when this
// one comes back empty. Throwing here used to take all three down
// together over one flaky dependency.
async function fetchOverpassPOIs(env, lat, lng, radiusM, categories, anchors) {
  const query = buildOverpassQuery(lat, lng, radiusM, categories, anchors);
  if (!query) return { pois: [], anchors: [], error: null, source: null };

  // FIRE-DRILL SWITCH (added 2026-09-20, v1.4.0). Set a plain-text
  // Variable named FORCE_OVERPASS_FAIL to 1 (Worker > Settings >
  // Variables and Secrets) and this function skips Overpass entirely —
  // AND ignores any warm Overpass cache — so the Geoapify backstop
  // below gets exercised for real, end to end, without waiting for
  // Overpass to actually break. Delete the Variable afterwards. Off
  // unless it is exactly "1", and only the owner of the Cloudflare
  // account can set it — never a visitor's request.
  // String() because the Cloudflare dashboard lets a variable be saved as
  // Text OR JSON — a JSON 1 arrives as the NUMBER 1, and a strict === '1'
  // would silently ignore the switch.
  const drill = String(env.FORCE_OVERPASS_FAIL) === '1';

  const cache = caches.default;
  const cacheKey = new Request('https://cache.internal/overpass/' + hashString(query));
  if (!drill) {
    const cached = await cache.match(cacheKey);
    if (cached) {
      const hit = await cached.json();
      // Entries written before v1.4.0 have no source field.
      return { ...hit, source: hit.source || 'overpass', cached: true };
    }
  }

  // Every mirror's failure is kept (not just the last one) so the
  // on-page message can say exactly what each returned.
  const failures = drill ? ['FORCE_OVERPASS_FAIL test switch is on \u2014 Overpass skipped on purpose'] : [];
  for (const endpoint of (drill ? [] : OVERPASS_MIRRORS)) {
    try {
      const resp = await fetchWithTimeout(endpoint, {
        method: 'POST',
        // Accept: application/json is deliberate, not decorative —
        // several independent reports of the same 406 this tool hit
        // point at a missing/mismatched Accept header as one likely
        // trigger. User-Agent is likewise deliberate, not decorative
        // (see APP_USER_AGENT above) — cheap to send, correct either way.
        headers: { 'Content-Type': 'text/plain', Accept: 'application/json', 'User-Agent': APP_USER_AGENT },
        body: query,
      });
      if (!resp.ok) { failures.push(endpoint + ' returned ' + resp.status); continue; }
      const data = await resp.json();

      // SOFT-FAILURE CHECK (added 2026-09-20, v1.4.0). Overpass reports a
      // query that timed out or ran out of memory as HTTP 200 with the
      // reason in a "remark" field — NOT as an error status — because
      // the server has usually started streaming the body before it
      // knows the query will fail, and by then it can no longer change
      // the status line (the maintainer's own explanation:
      // github.com/drolbr/Overpass-API, issue #94). Until this check
      // existed, such a reply looked like a perfectly good, EMPTY
      // answer: it skipped every remaining mirror AND the Geoapify
      // backstop, and was then cached for 24 hours as "no competitors
      // here". Treat it as a failed mirror instead. Partial results
      // alongside a runtime error are rejected too (an undercount would
      // quietly inflate the opportunity score), and nothing is cached.
      // A genuine empty answer has NO remark and is still accepted.
      const remark = typeof data.remark === 'string' ? data.remark : '';
      if (/runtime error/i.test(remark) || (remark && !(data.elements || []).length)) {
        failures.push(endpoint + ' reported: ' + remark.slice(0, 140));
        continue;
      }

      const pois = [];
      const anchorPois = [];
      (data.elements || []).forEach((el) => {
        const lat2 = el.lat != null ? el.lat : (el.center && el.center.lat);
        const lng2 = el.lon != null ? el.lon : (el.center && el.center.lon);
        if (lat2 == null || lng2 == null) return;
        const tags = el.tags || {};
        const name = (tags.name || tags['name:en']) || 'Unnamed';
        const category = categorize(tags, categories);
        if (category) { pois.push({ name, lat: lat2, lng: lng2, category }); return; }
        const anchorType = categorizeAnchor(tags, anchors);
        if (anchorType) anchorPois.push({ name, lat: lat2, lng: lng2, anchorType });
      });

      const result = { pois, anchors: anchorPois, error: null, source: 'overpass:' + hostOf(endpoint) };
      const response = new Response(JSON.stringify(result), { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=86400' } });
      await cache.put(cacheKey, response.clone());
      return result;
    } catch (e) {
      failures.push(endpoint + ': ' + e.message);
    }
  }

  // Every mirror failed. FIXED, 2026-09-16: try the Geoapify backstop
  // here before giving up — this is the fallback
  // MARKET_RADAR_SETUP_AND_GLOSSARY.md already described, now actually
  // wired in. Only reachable once every mirror above has failed, so
  // this never adds latency or spends Geoapify's daily credit on the
  // common path. Still not cached at the "all failed" level — a
  // genuine outage shouldn't be remembered for 24 hours; the next
  // Analyze click should try everything again for real.
  //
  // Geoapify has no anchor-institution categories mapped (see
  // GEOAPIFY_CATEGORY_MAP) — anchors simply comes back empty on this
  // path rather than guessing at a mapping. Competitor data and the
  // opportunity score are unaffected either way; the anchor overlay is
  // the one thing that goes quiet during a total Overpass outage.
  const geoapifyResult = await fetchGeoapifyPOIs(env, lat, lng, radiusM, categories, drill);
  if (geoapifyResult.pois.length > 0) return { pois: geoapifyResult.pois, anchors: [], error: null, source: 'geoapify', cached: !!geoapifyResult.cached, truncated: !!geoapifyResult.truncated };

  const geoapifyNote = !env.GEOAPIFY_API_KEY
    ? ' No Geoapify backstop is configured \u2014 this Worker looks for a secret named exactly GEOAPIFY_API_KEY; if you already added one, check Settings > Variables and Secrets for a misspelled or different name.'
    : geoapifyResult.error
      ? ' The Geoapify backstop also failed (' + geoapifyResult.error + ').'
      : ' The Geoapify backstop found nothing here either.';
  return { pois: [], anchors: [], error: 'Every Overpass mirror failed (' + (failures.join('; ') || 'no mirrors configured') + ').' + geoapifyNote + ' The catchment shape and district numbers below are unaffected.', source: null };
}

// Same "most specific wins" principle as categorize() above, adapted
// for Geoapify's own category strings: a bubble tea shop comes back
// carrying BOTH the generic catering.cafe and the specific
// catering.cafe.bubble_tea, so whichever mapped category has the
// more specific (more dot-separated) match wins, regardless of which
// order GEOAPIFY_CATEGORY_MAP's own entries happen to be in.
function categorizeGeoapify(placeCategories, categories) {
  let bestKey = null;
  let bestSpecificity = -1;
  for (const key of Object.keys(categories)) {
    for (const gc of GEOAPIFY_CATEGORY_MAP[key] || []) {
      if (placeCategories.includes(gc)) {
        const specificity = gc.split('.').length;
        if (specificity > bestSpecificity) { bestSpecificity = specificity; bestKey = key; }
      }
    }
  }
  return bestKey;
}

// Only ever called after every OVERPASS_MIRRORS entry has failed —
// see fetchOverpassPOIs above. Cached for 24 hours, same reasoning
// as the Overpass cache. Returns { pois: [], error: '...' } rather
// than throwing, same defensive pattern as the rest of this file.
async function fetchGeoapifyPOIs(env, lat, lng, radiusM, categories, skipCache) {
  if (!env.GEOAPIFY_API_KEY) return { pois: [], error: 'no Geoapify key configured' };

  const geoapifyCategories = new Set();
  Object.keys(categories).forEach((key) => {
    (GEOAPIFY_CATEGORY_MAP[key] || []).forEach((c) => geoapifyCategories.add(c));
  });
  // e.g. a "custom" OSM-tag request, or "printing" alone — Geoapify
  // has no mapped category to even ask for.
  if (!geoapifyCategories.size) return { pois: [], error: null };

  const categoryList = [...geoapifyCategories].sort();
  const cache = caches.default;
  const cacheKeyStr = categoryList.join(',') + '|' + lat.toFixed(3) + '|' + lng.toFixed(3) + '|' + radiusM + '|' + GEOAPIFY_RESULT_LIMIT;
  const cacheKey = new Request('https://cache.internal/geoapify/' + hashString(cacheKeyStr));
  // skipCache is true only during a FORCE_OVERPASS_FAIL fire drill, so
  // the drill makes a real, credit-spending call that proves the key
  // works instead of being answered from yesterday's cache.
  if (!skipCache) {
    const cached = await cache.match(cacheKey);
    if (cached) return { ...(await cached.json()), cached: true };
  }

  // Geoapify's circle filter wants lon,lat order — like ORS below,
  // this is the one place in this function that ISN'T [lat, lng].
  // (The key stays in the URL query string, which Geoapify's own spec
  // calls its recommended method; no code path here echoes this URL
  // into a message. Geoapify also accepts an x-api-key header, which
  // would keep the key out of any URL log — logged as a KIV item
  // rather than changed untested, since the backstop can't be
  // live-tested from where this file is built.)
  // bias=proximity orders results nearest-first. It matters because
  // GEOAPIFY_RESULT_LIMIT applies to ALL requested categories combined
  // (this tool asks for every category so the diversity index still
  // works): a 10-15 minute DRIVE catchment (radius up to ~10 km) can
  // hold far more than 500 places, and without an ordering the 500
  // returned would be an arbitrary slice — an undercount that quietly
  // inflates the opportunity score. With it, truncation drops the
  // FARTHEST places, and `truncated` below lets the page say so.
  const url = `https://api.geoapify.com/v2/places?categories=${categoryList.join(',')}&filter=circle:${lng},${lat},${radiusM}&bias=proximity:${lng},${lat}&limit=${GEOAPIFY_RESULT_LIMIT}&apiKey=${env.GEOAPIFY_API_KEY}`;
  try {
    const resp = await fetchWithTimeout(url);
    if (!resp.ok) {
      // Plain-English hints, so the on-page message is self-diagnosing
      // for someone who never opens this file.
      const hint = resp.status === 401 ? ' \u2014 key missing or rejected; check the GEOAPIFY_API_KEY secret'
        : resp.status === 429 ? ' \u2014 free-tier daily credits or the 5-requests-per-second limit reached'
        : resp.status === 400 ? ' \u2014 request rejected; a category name may be invalid'
        : '';
      return { pois: [], error: 'Geoapify returned ' + resp.status + hint };
    }
    const geojson = await resp.json();

    const features = geojson.features || [];
    const pois = features.map((f) => {
      const props = f.properties || {};
      // Geoapify documents every Places feature as a Point and always
      // includes lat/lon in properties — prefer those, fall back to a
      // Point geometry, and DROP anything that still can't be placed.
      // (Its OpenAPI spec technically allows other geometry types; the
      // old code read geometry.coordinates blindly, which for a Polygon
      // yielded a lat of undefined and an array for lng — enough to
      // make Leaflet throw and blank the whole result screen.)
      let placeLat = typeof props.lat === 'number' ? props.lat : NaN;
      let placeLng = typeof props.lon === 'number' ? props.lon : NaN;
      if (!Number.isFinite(placeLat) || !Number.isFinite(placeLng)) {
        const g = f.geometry;
        if (g && g.type === 'Point' && Array.isArray(g.coordinates)) { placeLng = g.coordinates[0]; placeLat = g.coordinates[1]; }
      }
      if (!Number.isFinite(placeLat) || !Number.isFinite(placeLng)) return null;
      const category = categorizeGeoapify(props.categories || [], categories);
      if (!category) return null;
      return { name: props.name || props.address_line1 || 'Unnamed', lat: placeLat, lng: placeLng, category };
    }).filter(Boolean);

    const result = { pois, error: null, source: 'geoapify', truncated: features.length >= GEOAPIFY_RESULT_LIMIT };
    const response = new Response(JSON.stringify(result), { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=86400' } });
    await cache.put(cacheKey, response.clone());
    return result;
  } catch (e) {
    // The key is part of the request URL, and this message is shown on
    // the public page. A network error can echo the URL it was
    // fetching, so scrub the key before it can reach any message.
    return { pois: [], error: 'Geoapify: ' + String(e.message).split(env.GEOAPIFY_API_KEY).join('[key hidden]') };
  }
}

/* ================= 1B. GOOGLE PLACES (optional competitor-strength) ================= */
// See the GOOGLE_PLACES_API_KEY note in this file's header — this
// entire section is skipped in under a millisecond if that env var
// isn't set, so it adds no latency or risk for anyone not using it.

function haversineMeters(lat1, lng1, lat2, lng2) {
  const R = 6371000;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

// Confirmed against developers.google.com/maps/documentation/places/
// web-service/nearby-search on 2026-09-16: endpoint, request shape,
// and field-mask tiers (displayName/location are Pro-tier fields;
// rating/userRatingCount are Enterprise-tier — mixing them bills the
// whole call at Enterprise, $35/1,000 after 1,000 free/month — see
// this file's header). rankPreference DISTANCE, not the POPULARITY
// default, because these results only matter here if they plausibly
// ARE the competitors this file already found nearby — a popular
// place across town is noise, not signal, for this purpose.
async function fetchGooglePopularity(env, lat, lng, radiusM, categories) {
  if (!env.GOOGLE_PLACES_API_KEY) return [];

  const types = new Set();
  Object.keys(categories).forEach((key) => {
    (GOOGLE_PLACE_TYPES[key] || []).forEach((t) => types.add(t));
  });
  if (!types.size) return []; // e.g. a "custom" OSM-tag request, or "printing" alone

  const typeList = [...types].sort();
  const cache = caches.default;
  const cacheKeyStr = typeList.join(',') + '|' + lat.toFixed(3) + '|' + lng.toFixed(3) + '|' + radiusM;
  const cacheKey = new Request('https://cache.internal/google-popularity/' + hashString(cacheKeyStr));
  const cached = await cache.match(cacheKey);
  if (cached) return cached.json();

  try {
    const resp = await fetchWithTimeout('https://places.googleapis.com/v1/places:searchNearby', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': env.GOOGLE_PLACES_API_KEY,
        'X-Goog-FieldMask': 'places.displayName,places.location,places.rating,places.userRatingCount',
      },
      body: JSON.stringify({
        includedTypes: typeList.slice(0, 50), // Google's own per-request cap; we're nowhere near it
        maxResultCount: 20, // Google's own per-request cap (1-20)
        rankPreference: 'DISTANCE',
        locationRestriction: { circle: { center: { latitude: lat, longitude: lng }, radius: Math.min(radiusM, 50000) } },
      }),
    });
    if (!resp.ok) return []; // fails open — this signal is optional by design, never worth breaking the rest of the analysis over
    const data = await resp.json();
    const places = (data.places || []).map((p) => {
      if (!p.location || p.rating == null) return null;
      return { name: (p.displayName && p.displayName.text) || 'Unnamed', lat: p.location.latitude, lng: p.location.longitude, rating: p.rating, reviewCount: p.userRatingCount || 0 };
    }).filter(Boolean);

    // Cached 24h, same as the other POI sources — ratings and review
    // counts drift slowly, and this conserves the free monthly cap.
    const response = new Response(JSON.stringify(places), { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=86400' } });
    await cache.put(cacheKey, response.clone());
    return places;
  } catch (e) {
    return [];
  }
}

// Attaches rating/reviewCount onto whichever already-classified
// Overpass/Geoapify pois sit within 75m of a Google result — never
// adds a NEW competitor Google found that Overpass/Geoapify missed,
// and never changes a POI's category. Google only ever answers "how
// well-known is this specific place", nothing else, here.
function attachGooglePopularity(pois, googlePlaces) {
  if (!googlePlaces.length) return pois;
  const MAX_MATCH_DISTANCE_M = 75;
  return pois.map((p) => {
    let best = null;
    let bestDist = MAX_MATCH_DISTANCE_M;
    for (const g of googlePlaces) {
      const d = haversineMeters(p.lat, p.lng, g.lat, g.lng);
      if (d <= bestDist) { bestDist = d; best = g; }
    }
    return best ? { ...p, rating: best.rating, reviewCount: best.reviewCount } : p;
  });
}

/* ================= 2. OPENROUTESERVICE (real catchment shape) ================= */

// Returns null on ANY failure — missing key, rate limit, network
// error, timeout — by design. market-radar.js already knows how to
// draw a plain circle instead when this comes back null, so a
// Worker-side throw here would take down the whole analysis over
// what should be a graceful, minor degradation.
async function fetchIsochrone(env, lat, lng, profile, seconds) {
  if (!env.ORS_API_KEY || !profile || !seconds) return null;

  const cache = caches.default;
  const cacheKey = new Request(`https://cache.internal/isochrone/${profile}/${seconds}/${lat.toFixed(3)}/${lng.toFixed(3)}`);
  const cached = await cache.match(cacheKey);
  if (cached) return cached.json();

  try {
    const resp = await fetchWithTimeout(ORS_ISOCHRONE_ENDPOINT + profile, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: env.ORS_API_KEY },
      body: JSON.stringify({ locations: [[lng, lat]], range: [seconds], range_type: 'time' }), // ORS wants [lng, lat] — the one place in this file that ISN'T [lat, lng]
    });
    if (!resp.ok) return null;
    const geojson = await resp.json();
    // Cached for 30 days — a town's road network and typical travel
    // speeds don't meaningfully change month to month, and this
    // conserves the shared 500/day free allowance.
    const response = new Response(JSON.stringify(geojson), { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=2592000' } });
    await cache.put(cacheKey, response.clone());
    return geojson;
  } catch (e) {
    return null;
  }
}

/* ================= 3. DATA.GOV.MY (district population & income) ================= */

function latestRow(rows) {
  if (!rows.length) return null;
  return rows.slice().sort((a, b) => new Date(b.date) - new Date(a.date))[0];
}

// FIXED, 2026-09-16 — confirmed against data.gov.my's own docs
// (developer.data.gov.my/request-query) and the population_district
// dataset's own published metadata
// (data.gov.my/data-catalogue/population_district), not guessed:
//
//   - population_district publishes ONE ROW PER (district × sex ×
//     age band × ethnicity) combination, not one row per district.
//     Fetching without narrowing this down (or even sorting by date
//     and taking the newest row) lands on one arbitrary demographic
//     slice — e.g. "males aged 20-24, Chinese ethnicity" — a small
//     fraction of the true district population, not the total. The
//     one row that IS the true district total is the one where
//     sex='both', age='overall', ethnicity='overall' — those exact
//     literal values, confirmed on the dataset's own metadata page.
//   - Multiple conditions must be comma-separated inside ONE ifilter=
//     parameter (?ifilter=a@col1,b@col2,...), not split across
//     separate filter=/ifilter= parameters — confirmed at
//     developer.data.gov.my/request-query. Splitting them reliably
//     returns zero rows even though each parameter's own syntax is
//     individually documented.
//   - The population column is published in THOUSANDS ('000 people)
//     — also confirmed on the dataset's metadata page — so the raw
//     API value needs multiplying by 1,000 to show a real headcount.
//   - CORRECTED, 2026-09-17: added sort=-date&limit=1 — also confirmed
//     at developer.data.gov.my/request-query (a documented parameter,
//     dash prefix = descending) — so the API itself returns the
//     newest year directly instead of this file downloading several
//     rows to sort client-side. latestRow() below still runs on
//     whatever comes back, purely as a free defensive backstop in
//     case that ever changes.
async function fetchPopulation(district) {
  const url = `${DATA_GOV_MY_ENDPOINT}?id=population_district&ifilter=${encodeURIComponent(district)}@district,both@sex,overall@age,overall@ethnicity&sort=-date&limit=1`;
  const resp = await fetchWithTimeout(url);
  if (!resp.ok) return 0;
  const body = await resp.json();
  const rows = Array.isArray(body) ? body : (body.data || []);
  const row = latestRow(rows);
  if (!row || row.population == null) return 0;
  return Math.round(Number(row.population) * 1000) || 0;
}

// hh_income_district has NO sex/age/ethnicity breakdown — one row per
// district per year — so this dataset was never hitting the
// "wrong slice" bug population_district had; income_median (confirmed
// on data.gov.my/data-catalogue/hh_income_district — the earlier
// guess was correct) is already a real RM figure, no unit conversion
// needed. Upgraded to the same server-side ifilter= approach anyway:
// one small targeted request instead of downloading up to 3,000 rows
// matters more than it looks, since data.gov.my allows only 4–10
// requests/minute total, shared across every visitor.
async function fetchIncome(district) {
  const url = `${DATA_GOV_MY_ENDPOINT}?id=hh_income_district&ifilter=${encodeURIComponent(district)}@district&sort=-date&limit=1`;
  const resp = await fetchWithTimeout(url);
  if (!resp.ok) return 0;
  const body = await resp.json();
  const rows = Array.isArray(body) ? body : (body.data || []);
  const row = latestRow(rows);
  return row ? (Number(row.income_median) || 0) : 0;
}

// Cached for 7 days per district: this is annual survey data, and
// the live endpoint allows only 4–10 requests a MINUTE total, shared
// across every visitor. Population and income are fetched in
// parallel and each individually swallows its own failure (falls
// back to 0, which the page correctly shows as "Not available"
// rather than a stale or wrong guess) so one dataset being down
// doesn't take the other out too.
async function fetchDemographics(district) {
  const cache = caches.default;
  const cacheKey = new Request('https://cache.internal/demographics/' + encodeURIComponent(district));
  const cached = await cache.match(cacheKey);
  if (cached) return cached.json();

  const [population, medianIncome] = await Promise.all([
    fetchPopulation(district).catch(() => 0),
    fetchIncome(district).catch(() => 0),
  ]);
  const result = { population, medianIncome };

  const response = new Response(JSON.stringify(result), { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=604800' } });
  await cache.put(cacheKey, response.clone());
  return result;
}

/* ================= 3B. DOSM WHOLESALE & RETAIL TRADE (national context) ================= */
// Answers "is this kind of business growing or shrinking, nationally" —
// requested 2026-09-18. Two things make this different from every other
// data source in this file, both worth being upfront about in the UI,
// not just here:
//   (1) It's Malaysia-WIDE. DOSM doesn't publish this broken down by
//       state or district at all, so this is national context sitting
//       alongside hyper-local numbers, not a local figure itself.
//   (2) It only covers MSIC Section G (wholesale & retail trade) — so
//       only "minimart", "bakery", "hardware", and "fashion" below have
//       any match at all. The F&B categories (cafe, restaurant, drinks,
//       etc.) sit in Section I, a completely different part of the
//       classification this index doesn't touch, and laundry/salon/
//       printing are services sections it doesn't touch either. That's
//       not a gap to route around — the index genuinely doesn't cover
//       those business types, so "not tracked" is the honest answer
//       for 7 of the 11 categories, not a failure of this function.
//
// The dataset ID for this (iowrt_3d) is explicitly marked "not
// available through OpenAPI" on its own data.gov.my page — unlike
// population_district/hh_income_district above, there's no ?id=
// endpoint for this one. But the CSV DOSM publishes for direct download
// is CC BY 4.0 licensed specifically for reuse like this, so this
// fetches that file directly and parses it, rather than treating
// "not on the filterable API" as "not accessible at all". Confirmed
// working file, confirmed column meanings, both as of 2026-09-18:
// storage.dosm.gov.my/iowrt/iowrt_3d.csv — columns include date,
// series_type ('abs'/'growth_yoy'/'growth_mom'), group (3-digit MSIC,
// matches the first 3 digits of the msic.code on each CATEGORY_TAGS
// entry), and one value column. Column order isn't hardcoded below —
// the header row is read first — specifically so a future column
// reshuffle on DOSM's end doesn't silently misread the wrong field.
//
// Cached for 30 days: this dataset updates monthly, so daily-cache
// churn would just be wasted bandwidth on both ends. If DOSM ever
// restructures this file and the parse below can't find what it
// expects, this returns null — same "fail honest, don't fake a number"
// rule as everywhere else in this file — and the card on the page
// shows "not available" rather than a stale or invented figure.
const IOWRT_GROUPS = {
  minimart: { group: '471', label: 'Retail sale in non-specialised stores' },
  bakery: { group: '472', label: 'Retail sale of food, beverages & tobacco (specialised stores)' },
  hardware: { group: '475', label: 'Retail sale of household/construction goods (specialised stores)' },
  fashion: { group: '477', label: 'Retail sale of other goods incl. clothing (specialised stores)' },
};

async function fetchWholesaleRetailTrend(categoryKey) {
  const groupInfo = IOWRT_GROUPS[categoryKey];
  if (!groupInfo) return null; // most categories genuinely aren't in this index — see header note

  const cache = caches.default;
  const cacheKey = new Request('https://cache.internal/iowrt/' + groupInfo.group);
  const cached = await cache.match(cacheKey);
  if (cached) return cached.json();

  try {
    const resp = await fetchWithTimeout('https://storage.dosm.gov.my/iowrt/iowrt_3d.csv', {}, 15000);
    if (!resp.ok) return null;
    const text = await resp.text();
    const lines = text.split('\n').filter((l) => l.trim().length);
    if (lines.length < 2) return null;

    const header = lines[0].split(',').map((h) => h.trim().replace(/^"|"$/g, ''));
    const dateIdx = header.indexOf('date');
    const seriesIdx = header.indexOf('series_type');
    const groupIdx = header.indexOf('group');
    if (dateIdx < 0 || seriesIdx < 0 || groupIdx < 0) return null;
    // The value column's exact name isn't confirmed the way date/
    // series_type/group are (those are named in the dataset's own
    // docs) — and the dataset's own description mentions "sales value
    // AND volume", so there may be more than one numeric column here,
    // not exactly one. Tried in this order per matching row, and only
    // accepted if it actually parses as a number for THAT row: a
    // column whose name hints at sales/value, then any unlabelled
    // column, then one hinting at volume/quantity, then literally
    // whatever's left — a wrong name guess just falls through to the
    // next candidate instead of silently returning NaN.
    const candidateIdxs = header.map((_, i) => i).filter((i) => i !== dateIdx && i !== seriesIdx && i !== groupIdx);
    if (!candidateIdxs.length) return null;
    const ordered = [
      ...candidateIdxs.filter((i) => /sales|value/i.test(header[i])),
      ...candidateIdxs.filter((i) => !/sales|value|volume|vol_index|quantity/i.test(header[i])),
      ...candidateIdxs.filter((i) => /volume|vol_index|quantity/i.test(header[i])),
    ];

    let best = null;
    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(',');
      if (cols[groupIdx] !== groupInfo.group || cols[seriesIdx] !== 'growth_yoy') continue;
      // ISO-style dates (YYYY-MM-DD) sort correctly as plain strings —
      // confirmed this dataset's date format matches every other DOSM
      // dataset already in this file.
      if (best && cols[dateIdx] <= best.date) continue;
      let value = NaN;
      for (const idx of ordered) { const n = Number(cols[idx]); if (Number.isFinite(n)) { value = n; break; } }
      if (Number.isFinite(value)) best = { date: cols[dateIdx], value };
    }
    if (!best) return null;

    const result = { group: groupInfo.group, label: groupInfo.label, growthYoy: best.value, asOf: best.date };
    const response = new Response(JSON.stringify(result), { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=2592000' } });
    await cache.put(cacheKey, response.clone());
    return result;
  } catch (e) {
    return null;
  }
}

/* ================= 4. GEMINI (narration only) ================= */
// Same calling convention as crypto-radar-worker.js's own handleInsight
// — plain generateContent, not the structured response_format/schema
// shape food-worth-proxy-worker.js uses, since this is free-text
// narration of numbers already computed, not data extraction.

async function handleInsight(env, body) {
  if (!env.GEMINI_API_KEY) return { error: 'Worker is missing GEMINI_API_KEY — add it in this Worker\u2019s Settings.' };
  const s = (body && body.snapshot) || {};

  const prompt = `You are a neutral market-data narrator for a small-business site-selection tool used in Sarawak, Malaysia.
Snapshot for a candidate spot in ${s.town || 'the area'}: category "${s.category}", ${s.competitorCount} competitors found inside the catchment, category mix ${Math.round((s.diversityIndex || 0) * 100)}% diverse (100% = evenly mixed, 0% = one category dominates), district population ${s.districtPopulation || 'unknown'}, district median household income RM${s.districtIncome || 'unknown'}/month, opportunity score ${s.opportunityScore ?? 'unknown'}/100.${s.catchmentIsReal ? '' : ' Note: the catchment shape used here is an estimated radius, not a real travel-time isochrone — mention this reduces precision.'}
Write 3-4 short sentences in plain English: what these numbers together suggest, one thing worth checking in person before relying on this, and how much confidence the data sources above actually support. Hard rules: never state a specific revenue or profit figure, never tell them to open or not open here — this describes the data, it does not recommend a decision. Never invent a number not given above.`;

  let resp;
  try {
    resp = await fetchWithTimeout(`${GEMINI_ENDPOINT}${GEMINI_MODEL}:generateContent?key=${env.GEMINI_API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0.4, maxOutputTokens: 220 } }),
    });
  } catch (e) {
    return { error: 'Could not reach Gemini. Try again.' };
  }
  if (!resp.ok) {
    const detail = await resp.text().catch(() => '');
    return { error: 'Gemini error ' + resp.status + (detail ? ': ' + detail.slice(0, 300) : '') };
  }
  const data = await resp.json();
  const text = data && data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts && data.candidates[0].content.parts[0] && data.candidates[0].content.parts[0].text;
  return { text: text || 'Gemini did not return a usable summary this time — the numbers already on the page are unaffected.' };
}

/* ================= ROUTER ================= */

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';

    if (request.method === 'OPTIONS') return new Response(null, { headers: corsHeaders(origin) });
    if (request.method !== 'POST') return json({ error: 'Method not allowed' }, 405, origin);

    let body;
    try { body = await request.json(); }
    catch (e) { return json({ error: 'Invalid request body' }, 400, origin); }

    if (body.mode === 'insight') {
      const result = await handleInsight(env, body);
      return json(result, result.error ? 500 : 200, origin);
    }

    const { lat, lng, categories, district, anchors, selectedCategory } = body;
    const radiusM = Number(body.radiusM) || 1000;
    if (typeof lat !== 'number' || typeof lng !== 'number' || !categories || typeof categories !== 'object') {
      return json({ error: 'Request needs at least lat, lng, and categories.' }, 400, origin);
    }

    try {
      const [overpassResult, isochrone, demographics, googlePopularity, wholesaleRetailTrend] = await Promise.all([
        fetchOverpassPOIs(env, lat, lng, radiusM, categories, anchors),
        body.isochrone ? fetchIsochrone(env, lat, lng, body.isochrone.profile, body.isochrone.seconds) : Promise.resolve(null),
        district ? fetchDemographics(district) : Promise.resolve({ population: 0, medianIncome: 0 }),
        fetchGooglePopularity(env, lat, lng, radiusM, categories),
        fetchWholesaleRetailTrend(selectedCategory),
      ]);
      const pois = attachGooglePopularity(overpassResult.pois, googlePopularity);
      // 200, not an error status, even when overpassResult.error is
      // set — this IS a successful response, it just carries a
      // partial-data flag inside it. market-radar.js checks
      // data.poisError itself and shows the catchment/demographics
      // results it DID get rather than a blank failure screen.
      return json({ pois, poisError: overpassResult.error, poisSource: overpassResult.source || null, poisCached: !!overpassResult.cached, poisTruncated: !!overpassResult.truncated, workerVersion: WORKER_VERSION, anchors: overpassResult.anchors, isochrone, demographics, wholesaleRetailTrend }, 200, origin);
    } catch (err) {
      return json({ error: 'Analysis failed: ' + (err.message || 'unknown error') }, 502, origin);
    }
  },
};
