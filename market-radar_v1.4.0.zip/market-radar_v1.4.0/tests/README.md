# Market Radar — tests

Two scripts that run the REAL Worker and browser code against pretend network answers.
No internet, no API keys, nothing is sent anywhere. Needs Node.js (built and run here on Node 22; 18+ should work).

Run from the folder that contains `market-radar.js`:

    node tests/test-worker.mjs market-radar-proxy-worker.js
    node tests/test-client.js  market-radar.js

Expected: `40/40 passed` and `all 9 client scenarios passed`. Any FAIL prints what it expected and what it got.

Run both after ANY edit to either file. Adding a new failure mode? Write the test first, watch it fail, then fix the code.
Full explanation: `MARKET_RADAR_SETUP_AND_GLOSSARY.md` -> "Re-running the checks".
