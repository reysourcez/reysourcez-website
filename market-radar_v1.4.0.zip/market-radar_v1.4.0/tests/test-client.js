/* ============================================================
   Market Radar CLIENT — integration test (fake DOM + fake Leaflet)
   Usage: node test-client.js <path-to-market-radar.js>
   Runs the real script in a sandbox, walks the wizard, then calls the
   real analyzeSpot() with canned Worker responses and inspects what
   the page would have displayed. The fake Leaflet throws on non-finite
   coordinates exactly like the real one, so a bad point cannot slip by.
   ============================================================ */
const vm = require('vm');
const fs = require('fs');

const file = process.argv[2];
if (!file) { console.error('usage: node test-client.js <market-radar.js>'); process.exit(2); }
const src = fs.readFileSync(file, 'utf8');

/* ---------- fake DOM ---------- */
const els = {};
function makeEl(id) {
  const el = {
    id, textContent: '', hidden: false, value: '', checked: true, disabled: false, style: {}, dataset: {},
    classList: {
      _s: new Set(),
      add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); },
      toggle(c, f) { const on = f === undefined ? !this._s.has(c) : !!f; on ? this._s.add(c) : this._s.delete(c); },
      contains(c) { return this._s.has(c); },
    },
    addEventListener() {}, querySelectorAll() { return []; }, focus() {},
  };
  el._html = '';
  Object.defineProperty(el, 'innerHTML', {
    configurable: true,
    // reading innerHTML after setting textContent returns the escaped text (what escapeHTML() relies on)
    get() { return el._html || String(el.textContent).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); },
    set(v) { el._html = v; },
  });
  return el;
}
const document = {
  getElementById(id) { return els[id] || (els[id] = makeEl(id)); },
  addEventListener(ev, fn) { if (ev === 'DOMContentLoaded') document._ready = fn; },
  createElement() { return makeEl('tmp'); },
};

/* ---------- fake Leaflet (throws on bad coordinates, like the real one) ---------- */
function chk(ll) {
  const a = Array.isArray(ll) ? ll[0] : ll.lat, b = Array.isArray(ll) ? ll[1] : ll.lng;
  if (!(Number.isFinite(a) && Number.isFinite(b))) throw new Error('Invalid LatLng object: (' + a + ', ' + b + ')');
}
const L = {
  map() { const m = { setView() { return m; }, on() {}, remove() {}, removeLayer() {}, fitBounds() {}, addLayer() {} }; return m; },
  tileLayer() { return { addTo() { return this; } }; },
  marker(ll) { chk(ll); const mk = { _ll: ll, setLatLng(x) { chk(x); mk._ll = x; }, getLatLng() { return { lat: mk._ll[0], lng: mk._ll[1] }; }, on() {}, addTo() { return mk; }, bindTooltip() { return mk; } }; return mk; },
  circle() { return { addTo() { return this; }, getBounds() { return {}; } }; },
  circleMarker(ll) { chk(ll); return { bindTooltip() { return this; }, addTo() { return this; } }; },
  geoJSON() { return { addTo() { return this; }, getBounds() { return {}; } }; },
  divIcon() { return {}; },
  heatLayer(pts) { pts.forEach(chk); return { addTo() { return this; } }; },
};

/* ---------- fake network: analyzeSpot() -> fetchAnalysis() -> fetch(WORKER_ENDPOINT) ---------- */
let nextPayload = {};
const fakeFetch = async () => ({ ok: true, status: 200, json: async () => nextPayload });

const sandbox = {
  document, L, fetch: fakeFetch, console: { info() {}, log: console.log, warn() {}, error: console.error },
  localStorage: { getItem() { return null; }, setItem() {} },
  window: { print() {} }, setInterval, clearInterval, setTimeout, clearTimeout,
};
const ctx = vm.createContext(sandbox);
vm.runInContext(src, ctx, { filename: 'market-radar.js' });
document._ready();                                   // init()
vm.runInContext("wizardAnswers.town='miri'; wizardAnswers.catchment='walk10'; finishWizard();", ctx);

// values the real page reads from its controls
document.getElementById('mr-category-select').value = 'cafe';
document.getElementById('mr-catchment-select').value = 'walk10';
document.getElementById('mr-observed-busyness').value = '';
for (const [k, v] of Object.entries({ lowCompetition: '0.35', population: '0.25', income: '0.15', diversity: '0.15', momentum: '0.10', competitorStrength: '0' })) els['mr-weight-' + k].value = v;

/* ---------- scenarios ---------- */
const NEAR = { lat: 4.4150, lng: 113.9920 };            // ~40 m from the Miri pin, inside the 800 m fallback circle
const POIS = [{ name: 'Kopitiam A', ...NEAR, category: 'cafe' }, { name: 'Cafe B', lat: 4.4155, lng: 113.9925, category: 'cafe' }];
const ANCHORS = [{ name: 'SK Miri', lat: 4.4160, lng: 113.9930, anchorType: 'school' }];
const BASE = { isochrone: null, demographics: { population: 350000, medianIncome: 5200 }, wholesaleRetailTrend: null };

const scenarios = [
  { name: 'S1 Overpass mirror, fresh, new Worker',
    payload: { ...BASE, pois: POIS, anchors: ANCHORS, poisError: null, poisSource: 'overpass:overpass.kumi.systems', poisCached: false, workerVersion: '1.4.0' },
    expect: { count: ['2', 'OSM via Overpass (overpass.kumi.systems)', 'Worker v1.4.0'], anchor: ['1'], status: ['Found 2 matching'], statusNot: ['Geoapify', 'backstop'] } },
  { name: 'S2 Geoapify backstop answered',
    payload: { ...BASE, pois: POIS, anchors: [], poisError: null, poisSource: 'geoapify', poisCached: false, workerVersion: '1.4.0' },
    expect: { count: ['2', 'Geoapify backstop', 'Worker v1.4.0'], anchor: ['Not checked'], anchorProv: ['no institution mapping'], status: ['Geoapify backstop', "weren't checked"] } },
  { name: 'S3 served from cache',
    payload: { ...BASE, pois: POIS, anchors: ANCHORS, poisError: null, poisSource: 'overpass:overpass-api.de', poisCached: true, workerVersion: '1.4.0' },
    expect: { count: ['cached up to 24h'], anchor: ['1'] } },
  { name: 'S4 OLD Worker still deployed (no new fields), good data',
    payload: { ...BASE, pois: POIS, anchors: ANCHORS, poisError: null },
    expect: { count: ['2', 'older than v1.4.0, redeploy'], anchor: ['1'] } },
  { name: 'S5 everything failed, OLD Worker',
    payload: { ...BASE, pois: [], anchors: [], poisError: 'Every Overpass mirror failed (x returned 429). No Geoapify backstop is configured.' },
    expect: { count: ['Unavailable', 'Worker version unknown'], anchor: ['Not checked'], anchorProv: ['Overpass unavailable'], status: ['Every Overpass mirror failed', 'Worker version unknown'] } },
  { name: 'S6 everything failed, NEW Worker',
    payload: { ...BASE, pois: [], anchors: [], poisError: 'Every Overpass mirror failed (a: 429; b: reported: runtime error). The Geoapify backstop also failed (Geoapify returned 401 \u2014 key missing or rejected).', poisSource: null, poisCached: false, workerVersion: '1.4.0' },
    expect: { count: ['Unavailable', 'Worker v1.4.0'], anchor: ['Not checked'], status: ['Geoapify returned 401', 'Worker v1.4.0'] } },
  { name: 'S8 backstop hit its 500-place cap => page warns of a possible undercount',
    payload: { ...BASE, pois: POIS, anchors: [], poisError: null, poisSource: 'geoapify', poisCached: false, poisTruncated: true, workerVersion: '1.4.0' },
    expect: { status: ['Geoapify backstop', '500-place cap', 'undercount'] } },
  { name: 'S9 backstop under the cap => no truncation warning',
    payload: { ...BASE, pois: POIS, anchors: [], poisError: null, poisSource: 'geoapify', poisCached: false, poisTruncated: false, workerVersion: '1.4.0' },
    expect: { status: ['Geoapify backstop'], statusNot: ['500-place', 'undercount'] } },
  { name: 'S7 genuine "0 competitors" from a healthy source stays a real zero',
    payload: { ...BASE, pois: [], anchors: [], poisError: null, poisSource: 'overpass:overpass.kumi.systems', poisCached: false, workerVersion: '1.4.0' },
    expect: { count: ['0', 'OSM via Overpass'], anchor: ['None found'], status: ['Found 0 matching'] } },
];

(async () => {
  let fails = 0;
  for (const s of scenarios) {
    nextPayload = s.payload;
    document.getElementById('mr-status').textContent = '';
    let thrown = null;
    try { await vm.runInContext('analyzeSpot()', ctx); } catch (e) { thrown = e; }
    const got = {
      count: document.getElementById('mr-competitor-count').innerHTML,
      anchor: document.getElementById('mr-anchor-value').textContent,
      anchorProv: document.getElementById('mr-anchor-provenance').textContent,
      status: document.getElementById('mr-status').textContent,
    };
    const problems = [];
    if (thrown) problems.push('threw: ' + thrown.message);
    for (const [field, needles] of Object.entries(s.expect)) {
      if (field === 'statusNot') { needles.forEach((n) => { if (got.status.includes(n)) problems.push(`status should NOT contain "${n}"`); }); continue; }
      needles.forEach((n) => { if (!String(got[field]).includes(n)) problems.push(`${field} missing "${n}"`); });
    }
    if (problems.length) fails++;
    console.log((problems.length ? 'FAIL' : 'PASS') + '  ' + s.name);
    if (problems.length) { problems.forEach((p) => console.log('        - ' + p)); console.log('        got:', JSON.stringify(got)); }
  }
  console.log(fails ? `\n${fails} scenario(s) FAILED` : `\nall ${scenarios.length} client scenarios passed`);
  process.exit(fails ? 1 : 0);
})();
