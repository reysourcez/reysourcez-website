/* ============================================================
   Market Radar Worker — behaviour tests (mocked network)
   ------------------------------------------------------------
   Usage:  node test-worker.mjs <path-to-worker.mjs> [--label NAME]
   Runs the REAL worker code with a fake global fetch() and a fake
   Cloudflare Cache API, so we can check what it actually does when
   Overpass fails in each of the ways it really fails — instead of
   trusting comments or docs (this project has been burned by docs
   describing code that wasn't there).
   Exit code 0 = every test passed; 1 = at least one failed.
   No network access needed. No real API keys are ever used.
   ============================================================ */
import { pathToFileURL } from 'node:url';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const workerPath = process.argv[2];
const label = process.argv.includes('--label') ? process.argv[process.argv.indexOf('--label') + 1] : workerPath;
if (!workerPath) { console.error('usage: node test-worker.mjs <worker.mjs>'); process.exit(2); }

/* ---------- fake Cloudflare Cache API ---------- */
function installFreshCache() {
  const store = new Map();
  globalThis.caches = {
    default: {
      async match(req) { const r = store.get(req.url); return r ? r.clone() : undefined; },
      async put(req, res) { store.set(req.url, res.clone()); },
    },
  };
  return store;
}

/* ---------- fake fetch(): scenario decides what each host answers ---------- */
let calls = [];
let scenario = () => new Response('{}', { status: 500 });
globalThis.fetch = async (url, opts) => {
  const u = String(url);
  calls.push({ url: u, opts: opts || {} });
  return scenario(u, opts || {});
};
const hits = (needle) => calls.filter((c) => c.url.includes(needle)).length;

/* ---------- canned responses ---------- */
const OVERPASS_HOSTS = ['overpass-api.de', 'overpass.kumi.systems', 'overpass.private.coffee'];
const isOverpass = (u) => OVERPASS_HOSTS.some((h) => u.includes(h));
const jsonRes = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { 'Content-Type': 'application/json' } });
const SOFT_FAIL = () => jsonRes({ elements: [], remark: 'runtime error: Query timed out in "query" at line 1 after 26 seconds.' });
const OOM_PARTIAL = () => jsonRes({ elements: [{ type: 'node', id: 9, lat: 4.41, lon: 113.99, tags: { amenity: 'cafe', name: 'Partial' } }], remark: 'runtime error: Query run out of memory using about 2048 MB of RAM.' });
const RATE_LIMITED = () => new Response('too many requests', { status: 429 });
const OVERPASS_OK = () => jsonRes({ elements: [
  { type: 'node', id: 1, lat: 4.4150, lon: 113.9920, tags: { amenity: 'cafe', name: 'Kopitiam A' } },
  { type: 'way', id: 2, center: { lat: 4.4160, lon: 113.9930 }, tags: { amenity: 'cafe', cuisine: 'bubble_tea', name: 'Boba B' } },
  { type: 'node', id: 3, lat: 4.4170, lon: 113.9940, tags: { amenity: 'school', name: 'SK Miri' } },
] });
const OVERPASS_GENUINELY_EMPTY = () => jsonRes({ elements: [] }); // real "nothing here", no remark

const GEO_FEATURES = [
  { type: 'Feature', properties: { name: 'Cafe G1', lat: 4.415, lon: 113.992, categories: ['catering', 'catering.cafe'] }, geometry: { type: 'Point', coordinates: [113.992, 4.415] } },
  // no properties.lat/lon -> must fall back to Point geometry; also carries the MORE specific bubble_tea category
  { type: 'Feature', properties: { name: 'Boba G2', categories: ['catering', 'catering.cafe', 'catering.cafe.bubble_tea'] }, geometry: { type: 'Point', coordinates: [113.993, 4.416] } },
  // non-Point geometry and no lat/lon: cannot be placed on the map -> must be dropped, never emitted with garbage coords
  { type: 'Feature', properties: { name: 'Polygon Bad', categories: ['catering.cafe'] }, geometry: { type: 'Polygon', coordinates: [[[113.9, 4.4], [113.9, 4.5], [114.0, 4.5], [113.9, 4.4]]] } },
  // real place but not one of OUR categories -> dropped
  { type: 'Feature', properties: { name: 'Petrol', lat: 1, lon: 1, categories: ['commercial.gas'] }, geometry: { type: 'Point', coordinates: [1, 1] } },
];
const GEO_OK = () => jsonRes({ type: 'FeatureCollection', features: GEO_FEATURES });

/* ---------- request helper ---------- */
const BODY = {
  lat: 4.4148, lng: 113.9917, radiusM: 1300, selectedCategory: 'cafe',
  categories: {
    cafe: { label: 'Cafe', tags: [['amenity', 'cafe']] },
    drinks: { label: 'Drinks', tags: [['cuisine', 'bubble_tea'], ['shop', 'tea']] },
  },
  anchors: { school: { label: 'School', tags: [['amenity', 'school']] } },
};
// The Worker file is named .js but uses ES-module syntax; Node needs .mjs (or module detection, Node 22+).
// Copy to a temp .mjs so `node tests/test-worker.mjs market-radar-proxy-worker.js` works on any Node 18+.
let importPath = path.resolve(workerPath);
if (importPath.endsWith('.js')) {
  const tmp = path.join(os.tmpdir(), 'mr-worker-under-test-' + process.pid + '.mjs');
  fs.copyFileSync(importPath, tmp);
  importPath = tmp;
  process.on('exit', () => { try { fs.unlinkSync(tmp); } catch (e) {} });
}
const mod = await import(pathToFileURL(importPath).href);
const worker = mod.default;
async function analyze(env, body = BODY) {
  const req = new Request('https://worker.test/', { method: 'POST', headers: { Origin: 'https://reysourcez.com', 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const res = await worker.fetch(req, env);
  return { status: res.status, data: await res.json() };
}
function reset(sc) { calls = []; scenario = sc; }

/* ---------- tiny test runner ---------- */
const results = [];
function check(name, cond, detail) { results.push({ name, ok: !!cond, detail: cond ? '' : (detail || '') }); }
const finite = (n) => typeof n === 'number' && Number.isFinite(n);

/* ======================== TESTS ======================== */
const KEY = { GEOAPIFY_API_KEY: 'TEST-GEO-KEY' };

// T1 — THE SUSPECTED HOLE: every mirror "succeeds" with HTTP 200 + a runtime-error remark
installFreshCache(); reset((u) => isOverpass(u) ? SOFT_FAIL() : u.includes('geoapify') ? GEO_OK() : jsonRes({}));
let r = await analyze(KEY);
check('T1a soft-failure (200+remark) on all mirrors => Geoapify backstop IS called', hits('api.geoapify.com') === 1, `geoapify calls=${hits('api.geoapify.com')}`);
check('T1b ...and its places are returned', r.data.pois && r.data.pois.length === 2, `pois=${JSON.stringify(r.data.pois)}`);
check('T1c ...with no error flag', r.data.poisError === null, `poisError=${r.data.poisError}`);
const overpassCallsRound1 = calls.filter((c) => isOverpass(c.url)).length;
calls = [];
r = await analyze(KEY);
check('T1d soft-failure is NOT cached: a repeat request tries Overpass again', calls.filter((c) => isOverpass(c.url)).length === 3, `overpass calls on repeat=${calls.filter((c) => isOverpass(c.url)).length} (0 means a "0 competitors" lie was cached)`);

// T1e — soft failure with NO Geoapify key must surface as an honest error, not "0 competitors"
installFreshCache(); reset((u) => isOverpass(u) ? SOFT_FAIL() : jsonRes({}));
r = await analyze({});
check('T1e soft-failure + no key => honest error (not a silent "0 competitors")', !!r.data.poisError, `poisError=${r.data.poisError}`);

// T1f — partial data with a runtime error must not be trusted either
installFreshCache(); reset((u) => isOverpass(u) ? OOM_PARTIAL() : u.includes('geoapify') ? GEO_OK() : jsonRes({}));
r = await analyze(KEY);
check('T1f partial results + "runtime error" remark are rejected (undercount would skew the score)', hits('api.geoapify.com') === 1, `geoapify calls=${hits('api.geoapify.com')}`);

// T2 — one soft-failing mirror, next mirror healthy: use it, do not spend Geoapify credits
installFreshCache(); reset((u) => u.includes('overpass-api.de') ? RATE_LIMITED() : u.includes('kumi') ? SOFT_FAIL() : u.includes('private.coffee') ? OVERPASS_OK() : jsonRes({}));
r = await analyze(KEY);
check('T2a falls through 429 then soft-failure to the healthy 3rd mirror', r.data.pois && r.data.pois.length === 2 && r.data.anchors.length === 1, `pois=${r.data.pois && r.data.pois.length} anchors=${r.data.anchors && r.data.anchors.length}`);
check('T2b Geoapify NOT called when a mirror worked (no wasted credits)', hits('api.geoapify.com') === 0);
check('T2c response says which mirror answered', String(r.data.poisSource || '').includes('overpass.private.coffee'), `poisSource=${r.data.poisSource}`);

// T3 — all mirrors rate-limited (the original shared-IP problem) => Geoapify backstop
installFreshCache(); reset((u) => isOverpass(u) ? RATE_LIMITED() : u.includes('geoapify') ? GEO_OK() : jsonRes({}));
r = await analyze(KEY);
check('T3a all mirrors 429 => Geoapify used', hits('api.geoapify.com') === 1);
check('T3b bubble-tea place ends up in "drinks" (most-specific category wins)', (r.data.pois || []).some((p) => p.name === 'Boba G2' && p.category === 'drinks'), `pois=${JSON.stringify(r.data.pois)}`);
check('T3c every returned place has finite lat/lng (bad geometry cannot crash the map)', (r.data.pois || []).length > 0 && r.data.pois.every((p) => finite(p.lat) && finite(p.lng)), `pois=${JSON.stringify(r.data.pois)}`);
check('T3d non-placeable + non-matching features dropped', (r.data.pois || []).length === 2, `count=${(r.data.pois || []).length}`);
check('T3e response labels the backstop as the source', r.data.poisSource === 'geoapify', `poisSource=${r.data.poisSource}`);
check('T3f Geoapify request uses the correct endpoint + lon,lat filter order + limit', (() => { const u = (calls.find((c) => c.url.includes('geoapify')) || {}).url || ''; return u.startsWith('https://api.geoapify.com/v2/places?') && u.includes('filter=circle:113.9917,4.4148,1300') && u.includes('limit=500'); })(), (calls.find((c) => c.url.includes('geoapify')) || {}).url);
check('T3g Geoapify request only ever contains categories that exist in Geoapify\'s published enum', (() => {
  const VALID = new Set(['catering.cafe', 'catering.cafe.bubble_tea', 'catering.cafe.tea', 'commercial.food_and_drink.coffee_and_tea', 'commercial.food_and_drink.drinks', 'catering.restaurant', 'catering.fast_food', 'commercial.food_and_drink.bakery', 'commercial.food_and_drink.confectionery', 'commercial.convenience', 'commercial.supermarket', 'commercial.clothing', 'commercial.houseware_and_hardware.hardware_and_tools', 'commercial.houseware_and_hardware.doityourself', 'service.cleaning.laundry', 'service.beauty.hairdresser', 'service.beauty']);
  const u = (calls.find((c) => c.url.includes('geoapify')) || {}).url || '';
  const cats = (u.match(/categories=([^&]+)/) || [, ''])[1].split(',').filter(Boolean);
  return cats.length > 0 && cats.every((c) => VALID.has(c));
})());

// T4 — no Geoapify key configured: message must name the exact secret to create
installFreshCache(); reset((u) => isOverpass(u) ? RATE_LIMITED() : jsonRes({}));
r = await analyze({});
check('T4a no key => honest error, no fake data', !!r.data.poisError && (r.data.pois || []).length === 0, `poisError=${r.data.poisError}`);
check('T4b ...error names the exact secret GEOAPIFY_API_KEY', String(r.data.poisError).includes('GEOAPIFY_API_KEY'), `poisError=${r.data.poisError}`);
check('T4c ...and warns about a wrong/misspelled secret name', /exact|spell|typo|name/i.test(String(r.data.poisError)), `poisError=${r.data.poisError}`);

// T5 — Geoapify itself failing: message must say why in plain words
for (const [status, re, tag] of [[401, /key/i, 'key rejected'], [429, /credit|limit|quota/i, 'quota'], [400, /categor|request/i, 'bad request']]) {
  installFreshCache(); reset((u) => isOverpass(u) ? RATE_LIMITED() : u.includes('geoapify') ? new Response('{}', { status }) : jsonRes({}));
  r = await analyze(KEY);
  check(`T5 Geoapify HTTP ${status} => message includes ${status} and a plain-English hint (${tag})`, String(r.data.poisError).includes(String(status)) && re.test(String(r.data.poisError)), `poisError=${r.data.poisError}`);
}

// T6 — caching: good results cached and labelled; repeat request makes no external call
installFreshCache(); reset((u) => isOverpass(u) ? OVERPASS_OK() : jsonRes({}));
r = await analyze(KEY);
check('T6a first request: fresh, not cached', !r.data.poisCached, `poisCached=${r.data.poisCached}`);
calls = [];
r = await analyze(KEY);
check('T6b repeat request served from cache (0 Overpass calls)', calls.filter((c) => isOverpass(c.url)).length === 0);
check('T6c ...and the response says so + still names the original source', r.data.poisCached === true && String(r.data.poisSource || '').startsWith('overpass'), `poisCached=${r.data.poisCached} poisSource=${r.data.poisSource}`);

// T7 — fire drill switch
installFreshCache(); reset((u) => isOverpass(u) ? OVERPASS_OK() : u.includes('geoapify') ? GEO_OK() : jsonRes({}));
await analyze(KEY); // primes the Overpass cache with a GOOD answer
calls = [];
r = await analyze({ ...KEY, FORCE_OVERPASS_FAIL: '1' });
check('T7a FORCE_OVERPASS_FAIL=1 makes zero Overpass calls', calls.filter((c) => isOverpass(c.url)).length === 0);
check('T7b ...ignores a warm Overpass cache (otherwise the drill proves nothing)', hits('api.geoapify.com') === 1 && r.data.poisSource === 'geoapify', `geo=${hits('api.geoapify.com')} src=${r.data.poisSource}`);
calls = [];
r = await analyze({ ...KEY, FORCE_OVERPASS_FAIL: '0' });
check('T7c switch set to anything but "1" is inert', calls.filter((c) => isOverpass(c.url)).length === 0 && r.data.poisCached === true, `poisCached=${r.data.poisCached}`);

// T8 — a REAL empty answer must stay a real "0 competitors" (backstop must not over-trigger)
installFreshCache(); reset((u) => isOverpass(u) ? OVERPASS_GENUINELY_EMPTY() : u.includes('geoapify') ? GEO_OK() : jsonRes({}));
r = await analyze(KEY);
check('T8a genuine empty (no remark) => accepted as-is', r.data.poisError === null && r.data.pois.length === 0, `poisError=${r.data.poisError} pois=${r.data.pois && r.data.pois.length}`);
check('T8b ...Geoapify not called', hits('api.geoapify.com') === 0);

// T9 — deployment visibility
installFreshCache(); reset((u) => isOverpass(u) ? OVERPASS_OK() : jsonRes({}));
r = await analyze(KEY);
check('T9 response carries workerVersion so the page can show what is actually deployed', typeof r.data.workerVersion === 'string' && /^\d+\.\d+\.\d+$/.test(r.data.workerVersion), `workerVersion=${r.data.workerVersion}`);

// T10 — the wrong-secret-name hazard (documenting what a mis-named secret does)
installFreshCache(); reset((u) => isOverpass(u) ? RATE_LIMITED() : u.includes('googleapis') ? new Response('{}', { status: 400 }) : jsonRes({}));
r = await analyze({ GOOGLE_PLACES_API_KEY: 'FAKE-GEOAPIFY-KEY-IN-WRONG-SLOT' });
const gcall = calls.find((c) => c.url.includes('googleapis'));
check('T10a [hazard demo] a Geoapify key stored under the Google name is sent to Google', !!gcall && (gcall.opts.headers || {})['X-Goog-Api-Key'] === 'FAKE-GEOAPIFY-KEY-IN-WRONG-SLOT', 'no google call observed');
check('T10b [hazard demo] ...and the backstop reports as unconfigured', /No Geoapify backstop/i.test(String(r.data.poisError)), `poisError=${r.data.poisError}`);
installFreshCache(); reset((u) => isOverpass(u) ? OVERPASS_OK() : jsonRes({}));
await analyze(KEY);
check('T10c with no Google key, nothing is ever sent to Google', hits('googleapis') === 0);

// T7d — Cloudflare lets a variable be saved as Text OR JSON; JSON 1 arrives as a NUMBER
installFreshCache(); reset((u) => isOverpass(u) ? OVERPASS_OK() : u.includes('geoapify') ? GEO_OK() : jsonRes({}));
r = await analyze({ ...KEY, FORCE_OVERPASS_FAIL: 1 });
check('T7d fire drill also works when the dashboard variable was saved as JSON (number 1)', r.data.poisSource === 'geoapify', `poisSource=${r.data.poisSource}`);

// T11 — the API key must never reach an on-page message, even if a network error echoes the URL
installFreshCache(); reset((u) => {
  if (isOverpass(u)) return RATE_LIMITED();
  if (u.includes('geoapify')) throw new Error('request to ' + u + ' failed, reason: socket hang up');
  return jsonRes({});
});
r = await analyze(KEY);
check('T11a a network error that echoes the Geoapify URL does not leak the key into poisError', !JSON.stringify(r.data).includes('TEST-GEO-KEY'), `poisError=${r.data.poisError}`);
check('T11b ...but the error still says the backstop failed', /Geoapify backstop also failed/.test(String(r.data.poisError)), `poisError=${r.data.poisError}`);

// T12 — Geoapify's limit applies across ALL categories combined: order by distance and flag truncation
const manyFeatures = (n) => Array.from({ length: n }, (_, i) => ({ type: 'Feature', properties: { name: 'C' + i, lat: 4.41 + i * 1e-5, lon: 113.99, categories: ['catering', 'catering.cafe'] }, geometry: { type: 'Point', coordinates: [113.99, 4.41 + i * 1e-5] } }));
installFreshCache(); reset((u) => isOverpass(u) ? RATE_LIMITED() : u.includes('geoapify') ? jsonRes({ type: 'FeatureCollection', features: manyFeatures(500) }) : jsonRes({}));
r = await analyze(KEY);
check('T12a hitting the 500-place cap is flagged (poisTruncated) so the page can warn of an undercount', r.data.poisTruncated === true, `poisTruncated=${r.data.poisTruncated}`);
check('T12b request asks Geoapify to order by distance from the pin so truncation drops the FARTHEST places', (() => { const u = (calls.find((c) => c.url.includes('geoapify')) || {}).url || ''; return u.includes('bias=proximity:113.9917,4.4148'); })(), (calls.find((c) => c.url.includes('geoapify')) || {}).url);
installFreshCache(); reset((u) => isOverpass(u) ? RATE_LIMITED() : u.includes('geoapify') ? GEO_OK() : jsonRes({}));
r = await analyze(KEY);
check('T12c a normal-sized answer is NOT flagged as truncated', r.data.poisTruncated === false, `poisTruncated=${r.data.poisTruncated}`);

/* ---------- report ---------- */
const pad = (s, n) => (s + ' '.repeat(n)).slice(0, n);
console.log(`\n=== ${label} ===`);
let fails = 0;
for (const t of results) {
  if (!t.ok) fails++;
  console.log(`${t.ok ? 'PASS' : 'FAIL'}  ${pad(t.name, 100)}${t.ok ? '' : '\n        -> ' + t.detail}`);
}
console.log(`\n${results.length - fails}/${results.length} passed, ${fails} failed`);
process.exit(fails ? 1 : 0);
