#!/bin/sh
# Market Radar regression suite. Put the "tests" folder NEXT TO the deliverables:
#   <folder>/market-radar.html  market-radar.js  market-radar-proxy-worker.js  tests/
# then:  sh tests/run_tests.sh
set -e
cd "$(dirname "$0")"
cp ../market-radar-proxy-worker.js ./market-radar-proxy-worker.mjs   # Node needs .mjs to import the Worker as an ES module
echo "=== Worker tests (real Worker code, mocked network) ==="
node test_worker.mjs
echo "=== Browser tests (real page in headless Chromium + real Worker code) ==="
node test_browser.cjs
