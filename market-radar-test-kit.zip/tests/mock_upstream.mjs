import assert from 'node:assert/strict';
// ---------- tiny in-memory Cache API ----------
export function makeCaches() {
  const store = new Map();
  return {
    default: {
      async match(req) { const hit = store.get(req.url); return hit ? hit.clone() : undefined; },
      async put(req, res) { store.set(req.url, res.clone()); },
    },
    _store: store,
  };
}

// ---------- mocked internet ----------
export const state = { calls: [], mode: {} };
const jsonRes = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { 'Content-Type': 'application/json' } });

// DOSM population_district shaped like the real dataset: district x sex x age x ethnicity x year
function populationRows(district) {
  const sexes = ['both', 'male', 'female'];
  const ages = ['overall', '0-4', '5-9', '10-14', '15-19', '20-24', '25-29', '30-34', '35-39', '40-44', '45-49', '50-54', '55-59', '60-64', '65-69', '70-74', '75-79', '80-84', '85+'];
  const eths = ['overall', 'bumi_malay', 'bumi_other', 'chinese', 'indian', 'other_citizen', 'other_noncitizen'];
  const rows = [];
  for (const date of ['2023-01-01', '2024-01-01']) {
    for (const sex of sexes) for (const age of ages) for (const ethnicity of eths) {
      const total = sex === 'both' && age === 'overall' && ethnicity === 'overall';
      rows.push({ state: 'Sarawak', district, date, sex, age, ethnicity, population: total ? (date === '2024-01-01' ? 736.4 : 731.9) : 12.3 });
    }
  }
  return rows;
}

export function installFetch() { globalThis.fetch = async (url, opts = {}) => {
  url = String(url);
  state.calls.push(url);
  const u = new URL(url);

  if (u.hostname === 'overpass-api.de' || u.hostname === 'overpass.kumi.systems' || u.hostname === 'overpass.private.coffee') {
    if (state.mode.overpassDown) return new Response('rate limited', { status: 429 });
    return jsonRes({ elements: [
      { type: 'node', lat: 4.4148, lon: 113.9917, tags: { amenity: 'restaurant', name: 'Restoran A' } },
      { type: 'node', lat: 4.4150, lon: 113.9920, tags: { amenity: 'restaurant', name: 'Restoran B' } },
      { type: 'node', lat: 4.4152, lon: 113.9925, tags: { amenity: 'cafe', name: 'Kopitiam C' } },
      { type: 'node', lat: 4.4153, lon: 113.9926, tags: { amenity: 'cafe', cuisine: 'bubble_tea', name: 'Boba D' } },
      { type: 'node', lat: 4.4155, lon: 113.9930, tags: { shop: 'bakery', name: 'Bakery E' } },
      { type: 'node', lat: 4.4156, lon: 113.9931, tags: { shop: 'convenience', name: 'Minimart F' } },
      { type: 'node', lat: 4.4160, lon: 113.9935, tags: { amenity: 'school', name: 'SMK G' } },
      { type: 'node', lat: 4.4161, lon: 113.9936, tags: { shop: 'bicycle', name: 'Bike H' } },
    ] });
  }
  if (u.hostname === 'api.geoapify.com') {
    return jsonRes({ features: [{ properties: { name: 'Geo Cafe', categories: ['catering.cafe'] }, geometry: { coordinates: [113.9917, 4.4148] } }] });
  }
  if (u.hostname === 'api.heigit.org') {
    return jsonRes({ features: [{ geometry: { coordinates: [[[113.98, 4.40], [114.00, 4.40], [114.00, 4.43], [113.98, 4.43], [113.98, 4.40]]] } }] });
  }
  if (u.hostname === 'api.data.gov.my') {
    const id = u.searchParams.get('id');
    const endpoint = u.pathname.replace(/\/$/, '');
    if (id === 'population_district') {
      if (endpoint === '/data-catalogue') return jsonRes([]);                     // the real-world behaviour found 2026-09-20
      if (state.mode.opendosm429) return jsonRes({ error: 'Too many requests' }, 429);
      if (state.mode.opendosmEmpty) return jsonRes([]);
      // emulate ifilter=<value>@district (case-insensitive), sort=-date, limit
      const ifilter = u.searchParams.get('ifilter') || '';
      assert.ok(!ifilter.includes(','), 'ifilter must be a SINGLE value@column (multi-column is only documented for filter)');
      const [value, column] = ifilter.split('@');
      assert.equal(column, 'district');
      let rows = populationRows(value).filter((r) => r.district.toLowerCase() === value.toLowerCase());
      rows.sort((a, b) => (a.date < b.date ? 1 : -1));
      return jsonRes(rows.slice(0, Number(u.searchParams.get('limit')) || rows.length));
    }
    if (id === 'hh_income_district') {
      if (endpoint === '/data-catalogue') return jsonRes([{ date: '2022-01-01', state: 'Sarawak', district: 'Miri', income_median: 6600, income_mean: 8100 }]);
      return jsonRes([]);
    }
  }
  if (u.hostname === 'storage.dosm.gov.my') {
    const csv = ['date,series_type,group,index', '2025-06-01,growth_yoy,471,3.2', '2025-07-01,growth_yoy,471,3.9', '2025-07-01,abs,471,120.5',
      '2025-07-01,growth_yoy,472,-2.1', '2025-07-01,growth_yoy,477,', '2025-06-01,growth_yoy,477,1.4'].join('\r\n');
    return new Response(csv, { status: 200 });
  }
  if (u.hostname === 'generativelanguage.googleapis.com') {
    if (state.mode.geminiLocation) return jsonRes({ error: { code: 400, message: 'User location is not supported for the API use.', status: 'FAILED_PRECONDITION' } }, 400);
    return jsonRes({ candidates: [{ content: { parts: [{ text: 'Gemini says: moderate competition.' }] } }] });
  }
  throw new Error('unexpected fetch in test: ' + url);
}; }
