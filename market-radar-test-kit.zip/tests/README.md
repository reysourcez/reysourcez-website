# Market Radar test kit (v1.5.0)

For a future AI session — **not part of the website; do not upload to GitHub Pages.**

Needs Node 20+ and Playwright with Chromium (`npm i playwright && npx playwright install chromium`).
Put this `tests` folder next to `market-radar.html`, `market-radar.js` and `market-radar-proxy-worker.js`, then run `sh tests/run_tests.sh`.
Expected: **17 Worker tests** and **27 browser checks** pass.

What it does: serves the real page at `https://reysourcez.com/`, stubs Leaflet, and answers the Worker URL by running the
real Worker code against a mocked internet (`mock_upstream.mjs`) that can reproduce the failures this project has met:
Data Catalogue returning `[]` for `population_district`, OpenDOSM 429/empty, every Overpass mirror 429, Gemini's
"User location is not supported for the API use", and a CSV with an empty newest cell.
Scenario list and rationale: `MARKET_RADAR_HANDOFF.md` section 12.

If you change a feature, add a test for it here first. A visual check once caught a bug the functional tests missed
(regex back-references pasted into markup) — keep the "no escape sequences in visible text" and "every card has a label" checks.
