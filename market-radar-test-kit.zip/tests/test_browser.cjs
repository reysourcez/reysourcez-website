// Run via run_tests.sh (needs: npm i playwright && npx playwright install chromium). Serves ../market-radar.html and ../market-radar.js.
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const os = require('node:os');
const HERE = __dirname;                    // the tests/ folder (holds the Worker .mjs copy and the mock)
const ROOT = path.resolve(__dirname, '..'); // the folder holding the deliverables
const SITE = 'https://reysourcez.com';
const WORKER_URL = 'https://market-radar-proxy.reysourcez-ent.workers.dev/';

// ---- stand-ins for things the sandbox cannot reach (real Leaflet CDN, the site's own styles.css) ----
const LEAFLET_STUB = `(function(){
  var rec = window.__rec = { markers: [], circleMarkers: [], heat: null, heatAdded: false, geo: null, circle: null, bounds: null };
  function makeMap(){ var m = { _h: {}, setView: function(){ return m; }, remove: function(){}, on: function(e, f){ m._h[e] = f; return m; },
    removeLayer: function(l){ if (l === rec.heat) rec.heatAdded = false; }, fitBounds: function(b){ rec.bounds = b; } }; rec.map = m; return m; }
  window.L = {
    map: makeMap,
    tileLayer: function(){ return { addTo: function(){ return this; } }; },
    marker: function(ll, opts){ var o = { _ll: { lat: ll[0], lng: ll[1] }, opts: opts, setLatLng: function(x){ o._ll = { lat: x[0], lng: x[1] }; }, getLatLng: function(){ return o._ll; },
      on: function(){ return o; }, addTo: function(){ rec.markers.push(o); return o; }, bindTooltip: function(t){ o.tip = t; return o; } }; return o; },
    circleMarker: function(ll, opts){ var o = { ll: ll, opts: opts, bindTooltip: function(t){ o.tip = t; return o; }, addTo: function(){ rec.circleMarkers.push(o); return o; } }; return o; },
    circle: function(ll, opts){ var o = { ll: ll, opts: opts, getBounds: function(){ return 'circleBounds'; }, addTo: function(){ rec.circle = o; return o; } }; return o; },
    geoJSON: function(gj, opts){ var o = { gj: gj, getBounds: function(){ return 'geoBounds'; }, addTo: function(){ rec.geo = o; return o; } }; return o; },
    heatLayer: function(points, opts){ var o = { points: points, opts: opts, addTo: function(){ rec.heatAdded = true; return o; } }; rec.heat = o; return o; },
    divIcon: function(o){ return o; }
  };
})();`;
const STYLES_STANDIN = `:root{--line:#D5DDD8;--surface:#fff;--paper:#F1F5F2;--accent:#1F6F5C;--accent-soft:#E2F0EA;--accent-dark:#15503f;--muted:#5C6D64;--text:#16261F;--font-body:'IBM Plex Sans',Arial,sans-serif;--font-display:Georgia,serif}
body{font-family:var(--font-body);color:var(--text);margin:0;background:#fff} [hidden]{display:none!important} .wrap{max-width:1040px;margin:0 auto;padding:0 16px}
.btn{padding:9px 16px;border-radius:6px;border:1px solid var(--accent);background:#fff;cursor:pointer}.btn-primary{background:var(--accent);color:#fff}
.ica-results{display:grid;grid-template-columns:repeat(2,1fr);gap:16px}.result-card{padding:8px 0;border-bottom:1px solid var(--line)}
.result-label{display:block;font-size:.75rem;text-transform:uppercase;color:var(--muted)}.result-value{display:block;font-family:monospace;font-size:1.4rem;font-weight:700}
.tooltip-icon{display:inline-block;margin-left:6px;width:16px;height:16px;border-radius:50%;background:#555;color:#fff;text-align:center;font-size:11px}
.wizard-options{display:flex;flex-wrap:wrap;gap:8px}.wizard-option{padding:10px 16px;border:1px solid var(--line);background:#fff;cursor:pointer}
.toggle-hint{font-weight:400;color:var(--muted);font-size:.8rem}.structure-note{font-size:.85rem;color:var(--muted)}.skip-link{position:absolute;left:-999px}
.no-print{}`;

// ---- Worker under test: the REAL file, with mocked upstream services ----
let workerMod, mock;
const scenario = { withAI: false, jsTweak: null };
function workerEnv() {
  const env = { GEMINI_API_KEY: 'g', ORS_API_KEY: 'o', GEOAPIFY_API_KEY: 'geo' };
  if (scenario.withAI) env.AI = { run: async () => ({ response: 'Workers AI narration: competition is moderate; check foot traffic on-site.' }) };
  return env;
}

let passed = 0;
async function step(name, fn) {
  try { await fn(); passed++; console.log('  ok  -', name); }
  catch (e) { console.error('FAIL  -', name, '\n', e.message.split('\n').slice(0, 12).join('\n')); process.exitCode = 1; }
}

(async () => {
  workerMod = (await import(path.join(HERE, 'market-radar-proxy-worker.mjs'))).default;
  mock = await import(path.join(HERE, 'mock_upstream.mjs'));
  globalThis.caches = mock.makeCaches();
  mock.installFetch();

  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 1100, height: 900 } });
  const workerRequests = [];
  const pageErrors = [];

  await context.route('**/*', async (route) => {
    const url = new URL(route.request().url());
    if (url.origin === SITE) {
      const file = url.pathname === '/' ? 'market-radar.html' : url.pathname.slice(1);
      if (file === 'styles.css') return route.fulfill({ status: 200, contentType: 'text/css', body: STYLES_STANDIN });
      const full = path.join(ROOT, file);
      if (['market-radar.html', 'market-radar.js'].includes(file) && fs.existsSync(full)) {
        let body = fs.readFileSync(full);
        if (file === 'market-radar.js' && scenario.jsTweak) { body = Buffer.from(body.toString('utf8').replace(scenario.jsTweak[0], scenario.jsTweak[1])); }
        return route.fulfill({ status: 200, contentType: file.endsWith('.html') ? 'text/html' : 'application/javascript', body });
      }
      return route.fulfill({ status: 200, contentType: 'text/plain', body: '' }); // costing-sync.js, nav-dropdown.js, icons...
    }
    if (url.href.startsWith(WORKER_URL)) {
      const req = route.request();
      const h = req.headers();
      const init = { method: req.method(), headers: { Origin: h['origin'] || '', 'Content-Type': h['content-type'] || 'application/json' } };
      if (req.method() === 'POST') { init.body = req.postData(); workerRequests.push(JSON.parse(req.postData())); }
      const res = await workerMod.fetch(new Request(WORKER_URL, init), workerEnv());
      const headers = {}; res.headers.forEach((v, k) => { headers[k] = v; });
      return route.fulfill({ status: res.status, headers, body: await res.text() });
    }
    if (url.hostname === 'cdnjs.cloudflare.com' && url.pathname.endsWith('leaflet.min.js')) return route.fulfill({ status: 200, contentType: 'application/javascript', body: LEAFLET_STUB });
    if (url.hostname === 'cdn.jsdelivr.net') return route.fulfill({ status: 200, contentType: 'application/javascript', body: '' });
    if (url.hostname === 'cdnjs.cloudflare.com') return route.fulfill({ status: 200, contentType: 'text/css', body: '' });
    return route.abort(); // google fonts, OSM tiles, etc.
  });

  const page = await context.newPage();
  page.on('pageerror', (e) => pageErrors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource|net::ERR/.test(m.text())) pageErrors.push('console.error: ' + m.text()); });

  await page.goto(SITE + '/market-radar.html');
  const $ = (sel) => page.locator(sel);
  const text = async (sel) => (await $(sel).innerText()).replace(/\s+/g, ' ').trim();

  // ---------------------------------------------------------------- wizard + new 5-minute presets
  await step('wizard step 2 offers all six catchments, including the new 5-minute walk and drive', async () => {
    await $('.wizard-option[data-value="miri"]').click();
    const labels = await $('.wizard-option').allInnerTexts();
    assert.deepEqual(labels, ['5-minute walk', '10-minute walk', '15-minute walk', '5-minute drive', '10-minute drive', '15-minute drive']);
    await $('.wizard-option[data-value="walk5"]').click();
    await $('#mr-analysis').waitFor({ state: 'visible' });
    const opts = await $('#mr-catchment-select option').allInnerTexts();
    assert.equal(opts.length, 6);
    assert.equal(await $('#mr-catchment-select').inputValue(), 'walk5', 'wizard answer carried into the dropdown');
  });

  await step('starting weights come from SCORE_WEIGHTS_DEFAULT (editing the documented constant really changes the page)', async () => {
    const boxes = await page.evaluate(() => ['lowCompetition', 'population', 'income', 'diversity', 'momentum', 'competitorStrength'].map((k) => document.getElementById('mr-weight-' + k).value));
    assert.deepEqual(boxes, ['0.35', '0.25', '0.15', '0.15', '0.10', '0.00']);
    scenario.jsTweak = ['lowCompetition: 0.35,', 'lowCompetition: 0.50,'];
    const p2 = await context.newPage();
    await p2.goto(SITE + '/market-radar.html');
    assert.equal(await p2.locator('#mr-weight-lowCompetition').inputValue(), '0.50', 'a changed constant must reach the page');
    await p2.close();
    scenario.jsTweak = null;
  });

  // ---------------------------------------------------------------- checkbox picker
  await step('picker: 12 checkboxes, Cafe ticked by default, counter reads "1 of 4 selected"', async () => {
    assert.equal(await $('#mr-category-options input[type="checkbox"]').count(), 12);
    assert.deepEqual(await $('#mr-category-options input:checked').evaluateAll((els) => els.map((e) => e.value)), ['cafe']);
    assert.equal(await text('#mr-category-count'), '1 of 4 selected');
    assert.equal(await $('#mr-category-select').count(), 0, 'old dropdown is gone');
  });

  await step('picker: cap of 4 - the 5th box is disabled, ticked ones stay clickable, untick frees the rest', async () => {
    for (const v of ['restaurant', 'bakery', 'drinks']) await $(`#mr-category-options input[value="${v}"]`).check();
    assert.equal(await text('#mr-category-count'), '4 of 4 selected \u2014 untick one to swap');
    assert.ok(await $('#mr-category-options input[value="laundry"]').isDisabled(), 'unticked box disabled at the cap');
    assert.ok(await $('#mr-category-options input[value="custom"]').isDisabled());
    assert.ok(await $('#mr-category-options input[value="cafe"]').isEnabled(), 'ticked box stays enabled so it can be swapped');
    // a forced click on a disabled box must not exceed the cap
    await $('#mr-category-options input[value="laundry"]').click({ force: true, timeout: 1000 }).catch(() => {});
    assert.equal((await $('#mr-category-options input:checked').count()), 4);
    await $('#mr-category-options input[value="cafe"]').uncheck();
    assert.equal(await text('#mr-category-count'), '3 of 4 selected');
    assert.ok(await $('#mr-category-options input[value="laundry"]').isEnabled(), 'freed up again');
    await $('#mr-category-options input[value="cafe"]').check();
  });

  await step('picker: custom tag row appears only while "Custom" is ticked (and counts toward the cap)', async () => {
    assert.ok(!(await $('#mr-custom-tag-row').isVisible()));
    await $('#mr-category-options input[value="bakery"]').uncheck();
    await $('#mr-category-options input[value="custom"]').check();
    assert.ok(await $('#mr-custom-tag-row').isVisible());
    assert.equal(await text('#mr-category-count'), '4 of 4 selected \u2014 untick one to swap');
    await $('#mr-category-options input[value="custom"]').uncheck();
    await $('#mr-category-options input[value="bakery"]').check();
    assert.ok(!(await $('#mr-custom-tag-row').isVisible()));
  });

  await step('validation: nothing ticked -> clear message and NO request sent', async () => {
    const before = workerRequests.length;
    for (const v of ['cafe', 'restaurant', 'bakery', 'drinks']) await $(`#mr-category-options input[value="${v}"]`).uncheck();
    assert.equal(await text('#mr-category-count'), '0 of 4 selected \u2014 tick at least one');
    await $('#mr-analyze-btn').click();
    assert.equal(await text('#mr-status'), 'Tick at least one business type first.');
    assert.equal(workerRequests.length, before);
  });

  await step('validation: bad custom OSM tag rejected client-side, no request sent', async () => {
    const before = workerRequests.length;
    await $('#mr-category-options input[value="custom"]').check();
    await $('#mr-custom-key').fill('shop');
    await $('#mr-custom-value').fill('a"](around:1');
    await $('#mr-analyze-btn').click();
    assert.match(await text('#mr-status'), /Custom OSM tags can only use letters, numbers/);
    assert.equal(workerRequests.length, before);
    await $('#mr-category-options input[value="custom"]').uncheck();
  });

  // ---------------------------------------------------------------- multi-category analysis, end to end
  await step('analysis with 4 types: request payload is what the Worker expects (5-minute walk)', async () => {
    for (const v of ['cafe', 'restaurant', 'bakery', 'drinks']) await $(`#mr-category-options input[value="${v}"]`).check();
    await $('#mr-analyze-btn').click();
    await $('#mr-result-cards').waitFor({ state: 'visible' });
    const req = workerRequests[workerRequests.length - 1];
    assert.deepEqual(req.selectedCategories, ['cafe', 'restaurant', 'bakery', 'drinks']);
    assert.equal(req.isochrone.seconds, 300);
    assert.equal(req.isochrone.profile, 'foot-walking');
    assert.equal(req.radiusM, 520, '400 m fallback x 1.3');
    assert.equal(req.district, 'Miri');
    assert.ok(!('custom' in req.categories), 'custom not sent unless ticked');
    assert.equal(Object.keys(req.categories).length, 11, 'all 11 standard types are always sent (keeps the category mix meaningful)');
    assert.ok(req.anchors.school);
    assert.ok(!('selectedCategory' in req));
  });

  await step('results: combined count, per-type breakdown, source + Worker version tag', async () => {
    const count = await text('#mr-competitor-count');
    assert.match(count, /^5 Estimated \u2014 OpenRouteService travel-time shape \u00b7 OSM via Overpass \(overpass-api\.de\) \u00b7 Worker v1\.5\.0$/);
    assert.equal(await text('#mr-competitor-breakdown'), '2 Restaurant \u00b7 1 Cafe / kopitiam \u00b7 1 Bakery / dessert \u00b7 1 Drink stall / bubble tea');
    assert.equal(await text('#mr-diversity-value'), '78% mixed');
    assert.match(await text('#mr-status'), /^Found 5 competitors across 4 business types \(2 Restaurant, 1 Cafe \/ kopitiam, 1 Bakery \/ dessert, 1 Drink stall \/ bubble tea\) in this catchment\.$/);
  });

  await step('results: DOSM population and income now display (the bug you reported)', async () => {
    assert.equal(await text('#mr-population-value'), '736,400');
    assert.match(await text('#mr-income-value'), /^RM6,600\/mo$/);
  });

  await step('every result card has its proper short label and a real tooltip (guards against markup damage)', async () => {
    const cards = await $('#mr-result-cards .result-card').evaluateAll((els) => els.map((e) => ({
      label: (e.querySelector('.result-label').firstChild.textContent || '').trim(),
      tip: e.querySelector('.tooltip-icon') ? e.querySelector('.tooltip-icon').getAttribute('data-tooltip') : null,
    })));
    assert.deepEqual(cards.map((c) => c.label), ['Competitors in catchment', 'Category mix nearby', 'District population', 'Median household income', 'Competitor strength', 'Nearby institutions', 'National retail trend']);
    for (const c of cards) assert.ok(c.tip && c.tip.length > 40 && !/\\[0-9u]/.test(c.tip), 'tooltip broken for ' + c.label);
    const strengthTip = cards[4].tip;
    assert.match(strengthTip, /^How strong the competition looks\. Your own on-site read/);
    assert.match(strengthTip, /counts it in the score at 10%, taken from Low competition \u2014 change it in the weights panel\.$/);
  });

  await step('results: markers carry their type in the tooltip; heat map added; anchors counted', async () => {
    const tips = await page.evaluate(() => window.__rec.circleMarkers.map((m) => m.tip).sort());
    assert.equal(tips.length, 5);
    assert.ok(tips.includes('Boba D \u2014 Drink stall / bubble tea'));
    assert.ok(tips.includes('Restoran A \u2014 Restaurant'));
    assert.ok(await page.evaluate(() => window.__rec.heatAdded));
    assert.equal(await text('#mr-anchor-value'), '1');
    assert.equal(await text('#mr-anchor-provenance'), 'Official \u2014 OSM: 1 School');
  });

  await step('trend card: Bakery tracked (-2.1% YoY); Restaurant/Cafe/Drinks listed as not tracked', async () => {
    assert.equal(await text('#mr-trend-value'), '-2.1% YoY');
    assert.equal(await text('#mr-trend-provenance'), 'Official \u2014 DOSM, as of 2025-07-01 \u00b7 Malaysia-wide, not Miri-specific \u00b7 Not tracked: Cafe / kopitiam, Restaurant, Drink stall / bubble tea');
  });

  await step('score: 12-per-type saturation scales with 4 types (5 competitors -> low-competition 0.90, not 0.58)', async () => {
    const parts = await page.evaluate(() => computeOpportunityScore(scoreInputs(), currentWeights()).parts);
    assert.ok(Math.abs(parts.lowCompetition - (1 - 5 / 48)) < 1e-9, 'lowCompetition=' + parts.lowCompetition);
    assert.equal(await text('#mr-score-number'), '87');
  });

  // ---------------------------------------------------------------- on-site read (the "doesn't change the rating" report)
  await step('on-site read: picking one now MOVES the score, visibly, and says why', async () => {
    await $('#mr-weights-panel summary').click(); // the weights panel is collapsed by default
    assert.equal(await $('#mr-weight-competitorStrength').inputValue(), '0.00');
    assert.ok(!(await $('#mr-observed-notice').isVisible()));
    await $('#mr-observed-busyness').selectOption('5'); // Packed
    assert.equal(await text('#mr-score-number'), '78');
    assert.equal(await $('#mr-weight-competitorStrength').inputValue(), '0.10');
    assert.equal(await $('#mr-weight-lowCompetition').inputValue(), '0.25');
    assert.equal(await text('#mr-weight-total'), '1.00');
    assert.match(await text('#mr-observed-notice'), /^Counted in the score at 10% \(taken from \u201cLow competition\u201d\)\./);
    assert.equal(await text('#mr-popularity-value'), 'Packed');
    assert.match(await text('#mr-popularity-provenance'), /^Observed \u2014 your own on-site read/);
  });

  await step('on-site read: Very quiet scores HIGHER than Packed (direction is right)', async () => {
    await $('#mr-observed-busyness').selectOption('1');
    assert.equal(await text('#mr-score-number'), '88');
    assert.equal(await text('#mr-popularity-value'), 'Very quiet');
    await $('#mr-observed-busyness').selectOption('5');
    assert.equal(await text('#mr-score-number'), '78');
    assert.equal(await $('#mr-weight-lowCompetition').inputValue(), '0.25', 'switching between reads must not keep shaving the weight');
  });

  await step('on-site read: clearing it restores the original weights and score exactly', async () => {
    await $('#mr-observed-busyness').selectOption('');
    assert.equal(await text('#mr-score-number'), '87');
    assert.equal(await $('#mr-weight-competitorStrength').inputValue(), '0.00');
    assert.equal(await $('#mr-weight-lowCompetition').inputValue(), '0.35');
    assert.ok(!(await $('#mr-observed-notice').isVisible()));
    assert.equal(await text('#mr-popularity-value'), 'No Google match');
  });

  await step('on-site read: a hand-edited weight switches the automation off (no surprise reverts)', async () => {
    await $('#mr-observed-busyness').selectOption('5');
    assert.equal(await $('#mr-weight-competitorStrength').inputValue(), '0.10');
    await $('#mr-weight-competitorStrength').fill('0.2');
    assert.ok(!(await $('#mr-observed-notice').isVisible()), 'notice hidden once the person takes over');
    await $('#mr-observed-busyness').selectOption('');
    assert.equal(await $('#mr-weight-competitorStrength').inputValue(), '0.2', 'their own number is left alone');
    await $('#mr-weight-competitorStrength').fill('0');
    await $('#mr-weight-lowCompetition').fill('0.35');
  });

  // ---------------------------------------------------------------- narration: Gemini location error -> Workers AI backstop
  await step('narration: Gemini location error, NO AI binding -> the page explains the fix in plain English', async () => {
    mock.state.mode.geminiLocation = true;
    scenario.withAI = false;
    await $('#mr-get-insight').click();
    await page.waitForFunction(() => /Couldn.t get a written read/.test(document.getElementById('mr-ai-insight').textContent));
    const t = await text('#mr-ai-insight');
    assert.match(t, /Cloudflare happened to run this Worker in a region Gemini doesn.t serve/);
    assert.match(t, /Workers AI binding named AI/);
    assert.match(t, /The numbers above are unaffected/);
  });

  await step('narration: same Gemini failure WITH the AI binding -> a read appears, labelled as Workers AI', async () => {
    scenario.withAI = true;
    await $('#mr-observed-busyness').selectOption('5');
    await $('#mr-get-insight').click();
    await page.waitForFunction(() => /Workers AI narration/.test(document.getElementById('mr-ai-insight').textContent));
    assert.match(await text('#mr-ai-insight'), /\(Written by Workers AI \u2014 Gemini was unavailable\.\)$/);
    const snap = workerRequests[workerRequests.length - 1].snapshot;
    assert.equal(snap.category, 'Cafe / kopitiam + Restaurant + Bakery / dessert + Drink stall / bubble tea');
    assert.equal(snap.breakdown.length, 4);
    assert.equal(snap.observedBusyness, 5, 'the on-site read is passed to the narrator');
    assert.equal(snap.opportunityScore, 78);
  });

  await step('narration: Gemini healthy -> plain Gemini text, no "Written by" suffix', async () => {
    mock.state.mode.geminiLocation = false;
    await $('#mr-get-insight').click();
    await page.waitForFunction(() => /Gemini says/.test(document.getElementById('mr-ai-insight').textContent));
    assert.equal(await text('#mr-ai-insight'), 'Gemini says: moderate competition.');
  });

  // ---------------------------------------------------------------- 5-minute drive + custom category + single-category regressions
  await step('5-minute drive + custom tag as one of the types: payload and results are right', async () => {
    await $('#mr-observed-busyness').selectOption('');
    for (const v of ['cafe', 'restaurant', 'bakery', 'drinks']) await $(`#mr-category-options input[value="${v}"]`).uncheck();
    await $('#mr-category-options input[value="custom"]').check();
    await $('#mr-category-options input[value="cafe"]').check();
    await $('#mr-custom-key').fill('shop');
    await $('#mr-custom-value').fill('bicycle');
    await $('#mr-catchment-select').selectOption('drive5');
    await $('#mr-analyze-btn').click();
    await page.waitForFunction(() => /Found \d+ competitor/.test(document.getElementById('mr-status').textContent));
    const req = workerRequests[workerRequests.length - 1];
    assert.equal(req.isochrone.profile, 'driving-car');
    assert.equal(req.isochrone.seconds, 300);
    assert.equal(req.radiusM, 3250, '2,500 m fallback x 1.3');
    assert.deepEqual(req.categories.custom, { label: 'shop=bicycle', tags: [['shop', 'bicycle']] });
    assert.equal(Object.keys(req.categories).length, 12, '11 standard + the custom tag');
    assert.match(await text('#mr-status'), /2 competitors across 2 business types \(1 Cafe \/ kopitiam, 1 shop=bicycle\)/);
  });

  await step('single type ticked behaves like before: plain sentence, no breakdown line, saturation stays 12', async () => {
    await $('#mr-category-options input[value="custom"]').uncheck();
    await $('#mr-category-options input[value="cafe"]').uncheck();
    await $('#mr-category-options input[value="restaurant"]').check();
    await $('#mr-analyze-btn').click();
    await page.waitForFunction(() => /matching Restaurant competitors/.test(document.getElementById('mr-status').textContent));
    assert.equal(await text('#mr-status'), 'Found 2 matching Restaurant competitors in this catchment.');
    assert.equal(await text('#mr-competitor-breakdown'), '');
    const parts = await page.evaluate(() => computeOpportunityScore(scoreInputs(), currentWeights()).parts);
    assert.ok(Math.abs(parts.lowCompetition - (1 - 2 / 12)) < 1e-9);
    assert.equal(await text('#mr-trend-provenance'), 'Restaurant isn\u2019t part of DOSM\u2019s wholesale & retail trade index (it only covers 4 of the 11 categories here \u2014 see the tooltip)');
  });

  await step('two tracked types (Minimart + Bakery) -> two labelled trend lines', async () => {
    await $('#mr-category-options input[value="restaurant"]').uncheck();
    await $('#mr-category-options input[value="minimart"]').check();
    await $('#mr-category-options input[value="bakery"]').check();
    await $('#mr-analyze-btn').click();
    await page.waitForFunction(() => /across 2 business types/.test(document.getElementById('mr-status').textContent));
    const lines = await $('#mr-trend-value .mr-trend-line').allInnerTexts();
    assert.deepEqual(lines.sort(), ['Bakery / dessert: -2.1% YoY', 'Convenience / minimart: +3.9% YoY']);
    assert.equal(await text('#mr-trend-provenance'), 'Official \u2014 DOSM, as of 2025-07-01 \u00b7 Malaysia-wide, not Miri-specific');
  });

  await $('#mr-observed-busyness').selectOption('5');
  await page.screenshot({ path: path.join(os.tmpdir(), 'mr_ok_desktop.png'), fullPage: true });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.screenshot({ path: path.join(os.tmpdir(), 'mr_ok_mobile.png'), fullPage: false, clip: { x: 0, y: 330, width: 390, height: 900 } });
  await page.setViewportSize({ width: 1100, height: 900 });
  await $('#mr-observed-busyness').selectOption('');

  // ---------------------------------------------------------------- DOSM failure explains itself
  await step('DOSM population failing shows WHY on the card instead of a bare "Not available"', async () => {
    mock.state.mode.opendosm429 = true;
    globalThis.caches = mock.makeCaches(); // cold cache so the lookup really runs
    await $('#mr-analyze-btn').click();
    await page.waitForFunction(() => /Not available/.test(document.getElementById('mr-population-value').textContent));
    const t = await text('#mr-population-value');
    assert.match(t, /^Not available Population: OpenDOSM API HTTP 429 \(rate-limited, retry in a minute\); Data Catalogue API returned no rows$/);
    assert.equal(await text('#mr-income-value'), 'RM6,600/mo', 'income unaffected');
    mock.state.mode.opendosm429 = false;
  });

  await page.screenshot({ path: path.join(os.tmpdir(), 'mr_analysis.png'), fullPage: true });
  await step('no literal escape sequences (\u2014, \1, \2 ...) leaked into any visible or tooltip text', async () => {
    const visible = await page.evaluate(() => document.body.innerText + ' ' + Array.from(document.querySelectorAll('[data-tooltip],[title]')).map((e) => (e.getAttribute('data-tooltip') || '') + ' ' + (e.getAttribute('title') || '')).join(' '));
    const hit = visible.match(/\\u[0-9a-fA-F]{4}|\\[0-9]/);
    assert.equal(hit, null, 'leaked: ' + (hit && visible.slice(Math.max(0, hit.index - 40), hit.index + 40)));
  });

  await step('no JavaScript errors were thrown anywhere in the session', async () => {
    assert.deepEqual(pageErrors, []);
  });

  console.log(`\n${passed} browser checks passed` + (process.exitCode ? ' (WITH FAILURES above)' : ''));
  await browser.close();
})().catch((e) => { console.error('HARNESS ERROR', e); process.exit(2); });
